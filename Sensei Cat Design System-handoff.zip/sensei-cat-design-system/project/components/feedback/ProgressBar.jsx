import React from 'react';

function useStyleOnce(id, css) {
  if (typeof document === 'undefined') return;
  if (document.getElementById(id)) return;
  const el = document.createElement('style'); el.id = id; el.textContent = css;
  document.head.appendChild(el);
}

const CSS = `
.sx-prog{ display:flex; flex-direction:column; gap:6px; font-family:var(--font-body); }
.sx-prog__top{ display:flex; justify-content:space-between; align-items:baseline; }
.sx-prog__label{ font-family:var(--font-display); font-weight:var(--fw-semibold); font-size:13px; color:var(--text-strong); }
.sx-prog__val{ font-family:var(--font-mono); font-weight:700; font-size:13px; color:var(--text-muted); }
.sx-prog__track{ height:14px; border-radius:var(--radius-pill); background:var(--cream-200);
  border:var(--border-2) solid var(--ink); overflow:hidden; }
.sx-prog__fill{ height:100%; border-radius:var(--radius-pill);
  background:var(--ginger-500); transition:width .4s cubic-bezier(.34,1.4,.64,1); }
.sx-prog__fill--cyan{ background:var(--cyan-500); }
.sx-prog__fill--grape{ background:var(--grape-500); }
.sx-prog__fill--gold{ background:var(--gold-500); }
.sx-prog__fill--success{ background:var(--success-500); }
`;

export function ProgressBar({
  value = 0, max = 100, label, showValue = true, tone = 'ginger', className = '',
}) {
  useStyleOnce('sx-prog-css', CSS);
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return (
    <div className={['sx-prog', className].filter(Boolean).join(' ')}>
      {(label || showValue) && (
        <div className="sx-prog__top">
          {label && <span className="sx-prog__label">{label}</span>}
          {showValue && <span className="sx-prog__val">{Math.round(pct)}%</span>}
        </div>
      )}
      <div className="sx-prog__track">
        <div className={`sx-prog__fill sx-prog__fill--${tone}`} style={{ width: pct + '%' }} />
      </div>
    </div>
  );
}
