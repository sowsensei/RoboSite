import * as React from 'react';

/** Ink-outlined progress / goal meter (e.g. subscriber goals, donation bars). */
export interface ProgressBarProps {
  value?: number;
  max?: number;
  label?: string;
  showValue?: boolean;
  /** @default "ginger" */
  tone?: 'ginger' | 'cyan' | 'grape' | 'gold' | 'success';
}

export function ProgressBar(props: ProgressBarProps): JSX.Element;
