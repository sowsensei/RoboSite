Ink-outlined progress / goal meter — subscriber goals, donation bars, upload progress.

```jsx
<ProgressBar label="Цель: 200K подписчиков" value={128} max={200} tone="ginger" />
```
