Pill-group segmented tabs in an ink-outlined track. Controlled via `value` / `onChange`.

```jsx
<Tabs tabs={[{id:'all',label:'Все'},{id:'dota',label:'Dota 2'},{id:'tech',label:'Техника'}]}
      value={tab} onChange={setTab} />
```
