import * as React from 'react';

/** Pill-group segmented tabs in an ink-outlined track. */
export interface TabItem { id: string; label: React.ReactNode; }
export interface TabsProps {
  /** Array of `{id,label}` or plain strings (id===label). */
  tabs: (TabItem | string)[];
  /** Active tab id. */
  value: string;
  onChange?: (id: string) => void;
}

export function Tabs(props: TabsProps): JSX.Element;
