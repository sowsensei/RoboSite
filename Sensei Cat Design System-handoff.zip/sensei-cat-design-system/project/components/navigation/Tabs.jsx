import React from 'react';

function useStyleOnce(id, css) {
  if (typeof document === 'undefined') return;
  if (document.getElementById(id)) return;
  const el = document.createElement('style'); el.id = id; el.textContent = css;
  document.head.appendChild(el);
}

const CSS = `
.sx-tabs{ display:inline-flex; gap:4px; padding:5px; background:var(--cream-100);
  border:var(--border-2) solid var(--ink); border-radius:var(--radius-pill); }
.sx-tab{
  font-family:var(--font-display); font-weight:var(--fw-bold); font-size:14px; line-height:1;
  padding:9px 18px; border-radius:var(--radius-pill); border:none; background:transparent;
  color:var(--brown-700); cursor:pointer; white-space:nowrap; transition:background .15s, color .15s;
}
.sx-tab:hover{ color:var(--ginger-700); }
.sx-tab--active{ background:var(--ginger-500); color:var(--text-on-brand);
  box-shadow:1.5px 1.5px 0 var(--ink); }
.sx-tab:focus-visible{ outline:none; box-shadow:var(--ring); }
`;

export function Tabs({ tabs = [], value, onChange, className = '' }) {
  useStyleOnce('sx-tabs-css', CSS);
  return (
    <div className={['sx-tabs', className].filter(Boolean).join(' ')} role="tablist">
      {tabs.map((t) => {
        const id = typeof t === 'string' ? t : t.id;
        const label = typeof t === 'string' ? t : t.label;
        const active = id === value;
        return (
          <button
            key={id}
            role="tab"
            aria-selected={active}
            className={['sx-tab', active && 'sx-tab--active'].filter(Boolean).join(' ')}
            onClick={() => onChange && onChange(id)}
          >
            {label}
          </button>
        );
      })}
    </div>
  );
}
