Sticker-style action button — chunky ink outline with a hard offset shadow that presses down on click. Use for any primary or secondary action.

```jsx
<Button variant="primary" size="md" onClick={save}>Сохранить</Button>
<Button variant="secondary" iconLeft={<PlayIcon/>}>Смотреть</Button>
<Button variant="ghost" size="sm">Отмена</Button>
```

Variants: `primary` (ginger), `secondary` (paper), `accent` (grape), `cool` (cyan), `danger` (red), `ghost` (borderless). Sizes: `sm` / `md` / `lg`. Props: `fullWidth`, `iconLeft`, `iconRight`, plus all native `<button>` attributes.
