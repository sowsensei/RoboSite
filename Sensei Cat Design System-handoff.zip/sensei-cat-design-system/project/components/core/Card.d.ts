import * as React from 'react';

/**
 * Content container. `default` is a soft warm card; `sticker` adds the
 * signature ink outline + hard pop shadow used across the brand.
 */
export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** @default "default" */
  variant?: 'default' | 'sticker' | 'flat';
  /** Lift / press affordance on hover. */
  interactive?: boolean;
  /** Optional media element rendered in a 16:9 header slot. */
  media?: React.ReactNode;
  children?: React.ReactNode;
}

export function Card(props: CardProps): JSX.Element;
