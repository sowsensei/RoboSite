import React from 'react';

/* Injects a component's CSS once per document. */
function useStyleOnce(id, css) {
  if (typeof document === 'undefined') return;
  if (document.getElementById(id)) return;
  const el = document.createElement('style');
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}

const CSS = `
.sx-btn{
  --_bg:var(--ginger-500); --_fg:var(--text-on-brand); --_bd:var(--ink); --_sh:var(--ink);
  font-family:var(--font-display); font-weight:var(--fw-bold); line-height:1;
  display:inline-flex; align-items:center; justify-content:center; gap:.5em;
  border:var(--border-2) solid var(--_bd); border-radius:var(--radius-pill);
  background:var(--_bg); color:var(--_fg); cursor:pointer; white-space:nowrap;
  box-shadow:2px 2px 0 var(--_sh); transition:transform .08s ease, box-shadow .08s ease, background .15s ease;
  -webkit-tap-highlight-color:transparent;
}
.sx-btn:hover{ transform:translate(-1px,-1px); box-shadow:3px 3px 0 var(--_sh); }
.sx-btn:active{ transform:translate(2px,2px); box-shadow:0 0 0 var(--_sh); }
.sx-btn:focus-visible{ outline:none; box-shadow:2px 2px 0 var(--_sh), var(--ring); }
.sx-btn[disabled]{ opacity:.5; cursor:not-allowed; transform:none; box-shadow:2px 2px 0 var(--_sh); }
.sx-btn--sm{ font-size:13px; padding:8px 14px; }
.sx-btn--md{ font-size:15px; padding:11px 20px; }
.sx-btn--lg{ font-size:18px; padding:15px 28px; }
.sx-btn--full{ width:100%; }
/* variants */
.sx-btn--primary{ --_bg:var(--ginger-500); --_fg:var(--text-on-brand); }
.sx-btn--primary:hover{ --_bg:var(--ginger-400); }
.sx-btn--secondary{ --_bg:var(--bg-surface); --_fg:var(--text-strong); }
.sx-btn--secondary:hover{ --_bg:var(--cream-100); }
.sx-btn--accent{ --_bg:var(--grape-500); --_fg:#fff; }
.sx-btn--accent:hover{ --_bg:var(--grape-400); }
.sx-btn--cool{ --_bg:var(--cyan-500); --_fg:#fff; }
.sx-btn--cool:hover{ --_bg:var(--cyan-400); }
.sx-btn--danger{ --_bg:var(--danger-500); --_fg:#fff; }
.sx-btn--ghost{ --_bg:transparent; --_fg:var(--text-strong); border-color:transparent; box-shadow:none; }
.sx-btn--ghost:hover{ --_bg:var(--cream-100); transform:none; box-shadow:none; }
.sx-btn--ghost:active{ transform:translate(1px,1px); box-shadow:none; }
.sx-btn--ghost:focus-visible{ box-shadow:var(--ring); }
`;

export function Button({
  children,
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  iconLeft = null,
  iconRight = null,
  type = 'button',
  className = '',
  ...rest
}) {
  useStyleOnce('sx-btn-css', CSS);
  const cls = [
    'sx-btn',
    `sx-btn--${variant}`,
    `sx-btn--${size}`,
    fullWidth ? 'sx-btn--full' : '',
    className,
  ].filter(Boolean).join(' ');
  return (
    <button type={type} className={cls} {...rest}>
      {iconLeft}
      {children != null && <span>{children}</span>}
      {iconRight}
    </button>
  );
}
