import * as React from 'react';

/**
 * Small status / category pill. Soft tonal fills plus a special
 * pulsing "live" tone for streams and premieres.
 */
export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Color tone. @default "ginger" */
  tone?: 'solid' | 'ginger' | 'grape' | 'cyan' | 'success' | 'danger' | 'warning' | 'neutral' | 'live';
  /** Show a leading status dot. */
  dot?: boolean;
  children?: React.ReactNode;
}

export function Badge(props: BadgeProps): JSX.Element;
