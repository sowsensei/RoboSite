import * as React from 'react';

/**
 * Filter / category chip. Becomes a toggle when `onClick` is supplied,
 * and removable when `onRemove` is supplied.
 */
export interface TagProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Selected state (for filter toggles). */
  active?: boolean;
  /** Makes the chip a clickable toggle. */
  onClick?: (e: React.MouseEvent) => void;
  /** Shows a ✕ remove affordance. */
  onRemove?: (e: React.MouseEvent) => void;
  children?: React.ReactNode;
}

export function Tag(props: TagProps): JSX.Element;
