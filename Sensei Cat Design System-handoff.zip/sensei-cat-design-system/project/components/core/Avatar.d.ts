import * as React from 'react';

/**
 * Round, ink-outlined avatar. Falls back to initials, can show a lavender
 * halo (à la the mascot) and an online dot.
 */
export interface AvatarProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Image URL. Omit to render initials from `name`. */
  src?: string | null;
  /** Used for initials and alt text. */
  name?: string;
  /** @default "md" */
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  /** Lavender halo behind the avatar. */
  halo?: boolean;
  /** Green online indicator. */
  online?: boolean;
}

export function Avatar(props: AvatarProps): JSX.Element;
