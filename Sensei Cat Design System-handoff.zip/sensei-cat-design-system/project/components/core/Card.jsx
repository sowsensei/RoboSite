import React from 'react';

function useStyleOnce(id, css) {
  if (typeof document === 'undefined') return;
  if (document.getElementById(id)) return;
  const el = document.createElement('style'); el.id = id; el.textContent = css;
  document.head.appendChild(el);
}

const CSS = `
.sx-card{
  background:var(--bg-surface); border-radius:var(--radius-xl); overflow:hidden;
  border:var(--border-1) solid var(--border-soft); box-shadow:var(--shadow-md);
  display:flex; flex-direction:column; transition:transform .12s ease, box-shadow .12s ease;
}
/* sticker = the comic look: ink outline + hard pop shadow */
.sx-card--sticker{ border:var(--border-2) solid var(--ink); box-shadow:var(--pop); }
.sx-card--flat{ box-shadow:none; }
.sx-card--interactive{ cursor:pointer; }
.sx-card--interactive:hover{ transform:translateY(-3px); box-shadow:var(--shadow-lg); }
.sx-card--sticker.sx-card--interactive:hover{ transform:translate(-2px,-2px); box-shadow:var(--pop-lg); }
.sx-card__media{ position:relative; aspect-ratio:16/9; background:var(--cream-200); overflow:hidden; }
.sx-card__media img{ width:100%; height:100%; object-fit:cover; display:block; }
.sx-card__body{ padding:var(--space-5); display:flex; flex-direction:column; gap:var(--space-2); }
`;

export function Card({
  children,
  variant = 'default',   // 'default' | 'sticker' | 'flat'
  interactive = false,
  media = null,
  className = '',
  ...rest
}) {
  useStyleOnce('sx-card-css', CSS);
  const cls = [
    'sx-card',
    variant !== 'default' ? `sx-card--${variant}` : '',
    interactive ? 'sx-card--interactive' : '',
    className,
  ].filter(Boolean).join(' ');
  return (
    <div className={cls} {...rest}>
      {media && <div className="sx-card__media">{media}</div>}
      <div className="sx-card__body">{children}</div>
    </div>
  );
}
