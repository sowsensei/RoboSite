Filter or category chip. Pass `onClick` to make it a toggle (use with `active`), `onRemove` to make it removable.

```jsx
<Tag active onClick={() => toggle('dota')}>Dota 2</Tag>
<Tag onRemove={() => drop('tag')}>гаджеты</Tag>
```
