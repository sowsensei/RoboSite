Round ink-outlined avatar. Shows an image, or initials from `name`. `halo` adds the mascot's lavender glow; `online` adds a status dot.

```jsx
<Avatar src="/sensei.png" name="Сенсей" size="lg" halo />
<Avatar name="Иван Котов" size="sm" online />
```

Sizes: `xs` `sm` `md` `lg` `xl`.
