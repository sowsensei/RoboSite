import React from 'react';

function useStyleOnce(id, css) {
  if (typeof document === 'undefined') return;
  if (document.getElementById(id)) return;
  const el = document.createElement('style'); el.id = id; el.textContent = css;
  document.head.appendChild(el);
}

const CSS = `
.sx-tag{
  font-family:var(--font-body); font-weight:var(--fw-bold); font-size:13px; line-height:1;
  display:inline-flex; align-items:center; gap:6px; cursor:default;
  padding:7px 12px; border-radius:var(--radius-pill);
  background:var(--cream-100); color:var(--brown-700);
  border:var(--border-1) solid var(--sand-300); transition:background .15s, border-color .15s, color .15s;
}
.sx-tag--clickable{ cursor:pointer; }
.sx-tag--clickable:hover{ background:var(--ginger-100); border-color:var(--ginger-300); color:var(--ginger-800); }
.sx-tag--active{ background:var(--ginger-500); border-color:var(--ink); color:var(--text-on-brand); }
.sx-tag__x{ display:inline-flex; width:14px; height:14px; align-items:center; justify-content:center;
  border-radius:50%; font-size:11px; line-height:1; opacity:.6; }
.sx-tag__x:hover{ opacity:1; }
`;

export function Tag({ children, active = false, onClick, onRemove, className = '', ...rest }) {
  useStyleOnce('sx-tag-css', CSS);
  const clickable = !!onClick;
  const cls = ['sx-tag', clickable && 'sx-tag--clickable', active && 'sx-tag--active', className]
    .filter(Boolean).join(' ');
  return (
    <span className={cls} onClick={onClick} {...rest}>
      {children}
      {onRemove && (
        <span className="sx-tag__x" onClick={(e) => { e.stopPropagation(); onRemove(e); }}>✕</span>
      )}
    </span>
  );
}
