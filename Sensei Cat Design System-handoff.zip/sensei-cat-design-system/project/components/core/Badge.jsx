import React from 'react';

function useStyleOnce(id, css) {
  if (typeof document === 'undefined') return;
  if (document.getElementById(id)) return;
  const el = document.createElement('style'); el.id = id; el.textContent = css;
  document.head.appendChild(el);
}

const CSS = `
.sx-badge{
  font-family:var(--font-display); font-weight:var(--fw-bold); font-size:12px; line-height:1;
  letter-spacing:.02em; display:inline-flex; align-items:center; gap:5px;
  padding:5px 10px; border-radius:var(--radius-pill); white-space:nowrap;
  border:var(--border-1) solid transparent;
}
.sx-badge .sx-dot{ width:7px; height:7px; border-radius:50%; background:currentColor; }
.sx-badge--solid{ color:var(--text-on-brand); background:var(--ginger-500); border-color:var(--ink); }
.sx-badge--ginger{ color:var(--ginger-800); background:var(--ginger-100); border-color:var(--ginger-300); }
.sx-badge--grape{ color:var(--grape-700); background:var(--lavender-100); border-color:var(--lavender-300); }
.sx-badge--cyan{ color:var(--cyan-700); background:var(--cyan-100); border-color:var(--cyan-300); }
.sx-badge--success{ color:var(--success-700); background:var(--success-100); border-color:#bfe6cf; }
.sx-badge--danger{ color:var(--danger-700); background:var(--danger-100); border-color:#f3cac6; }
.sx-badge--warning{ color:var(--warning-700); background:var(--warning-100); border-color:#f0dca0; }
.sx-badge--neutral{ color:var(--brown-700); background:var(--cream-200); border-color:var(--sand-300); }
.sx-badge--live{ color:#fff; background:var(--danger-500); border-color:var(--ink); }
.sx-badge--live .sx-dot{ animation:sx-pulse 1.4s infinite; }
@keyframes sx-pulse{ 0%,100%{opacity:1} 50%{opacity:.35} }
`;

export function Badge({ children, tone = 'ginger', dot = false, className = '', ...rest }) {
  useStyleOnce('sx-badge-css', CSS);
  const cls = ['sx-badge', `sx-badge--${tone}`, className].filter(Boolean).join(' ');
  return (
    <span className={cls} {...rest}>
      {dot && <span className="sx-dot" />}
      {children}
    </span>
  );
}
