import React from 'react';

function useStyleOnce(id, css) {
  if (typeof document === 'undefined') return;
  if (document.getElementById(id)) return;
  const el = document.createElement('style'); el.id = id; el.textContent = css;
  document.head.appendChild(el);
}

const CSS = `
.sx-avatar{
  position:relative; display:inline-flex; align-items:center; justify-content:center;
  border-radius:50%; background:var(--lavender-300); color:var(--ink); overflow:hidden;
  border:var(--border-2) solid var(--ink); flex:none;
  font-family:var(--font-display); font-weight:var(--fw-bold);
}
.sx-avatar img{ width:100%; height:100%; object-fit:cover; }
.sx-avatar--xs{ width:28px; height:28px; font-size:11px; border-width:1.5px; }
.sx-avatar--sm{ width:36px; height:36px; font-size:13px; }
.sx-avatar--md{ width:48px; height:48px; font-size:17px; }
.sx-avatar--lg{ width:64px; height:64px; font-size:22px; }
.sx-avatar--xl{ width:88px; height:88px; font-size:30px; }
.sx-avatar--halo::after{
  content:""; position:absolute; inset:-26%; z-index:-1; border-radius:50%;
  background:radial-gradient(circle,var(--lavender-300) 30%, transparent 70%);
}
.sx-avatar__ring{ position:relative; display:inline-flex; }
.sx-avatar__ring::before{
  content:""; position:absolute; inset:-5px; border-radius:50%;
  border:var(--border-2) solid var(--ginger-500);
}
.sx-avatar__online{
  position:absolute; right:-1px; bottom:-1px; width:30%; height:30%;
  background:var(--success-500); border:2px solid var(--bg-surface); border-radius:50%;
}
`;

export function Avatar({
  src = null, name = '', size = 'md', halo = false, online = false, className = '', ...rest
}) {
  useStyleOnce('sx-avatar-css', CSS);
  const initials = name
    ? name.trim().split(/\s+/).slice(0, 2).map((w) => w[0]).join('').toUpperCase()
    : '?';
  const cls = ['sx-avatar', `sx-avatar--${size}`, halo && 'sx-avatar--halo', className]
    .filter(Boolean).join(' ');
  return (
    <span className={cls} {...rest}>
      {src ? <img src={src} alt={name} /> : initials}
      {online && <span className="sx-avatar__online" />}
    </span>
  );
}
