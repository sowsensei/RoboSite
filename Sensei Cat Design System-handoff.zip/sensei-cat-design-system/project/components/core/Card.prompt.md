Content container. `default` is a soft warm card; `sticker` is the signature comic look (ink outline + hard pop shadow). Pass `media` for a 16:9 header (thumbnail), `interactive` for hover lift.

```jsx
<Card variant="sticker" interactive media={<img src="thumb.jpg" alt=""/>}>
  <h3>Как Сенсей собрал ПК</h3>
  <p>12 минут · 84K просмотров</p>
</Card>
```
