Small status or category pill with soft tonal fills. Use the `live` tone (pulsing dot) for streams and premieres.

```jsx
<Badge tone="live" dot>В ЭФИРЕ</Badge>
<Badge tone="cyan">Гаджеты</Badge>
<Badge tone="success" dot>Готово</Badge>
```

Tones: `solid`, `ginger`, `grape`, `cyan`, `success`, `danger`, `warning`, `neutral`, `live`. Prop `dot` adds a leading status dot.
