import * as React from 'react';

/** Ink-outlined toggle switch with a springy thumb. */
export interface SwitchProps {
  checked?: boolean;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  /** Optional inline label. */
  label?: string;
  disabled?: boolean;
}

export function Switch(props: SwitchProps): JSX.Element;
