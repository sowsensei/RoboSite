import React from 'react';

function useStyleOnce(id, css) {
  if (typeof document === 'undefined') return;
  if (document.getElementById(id)) return;
  const el = document.createElement('style'); el.id = id; el.textContent = css;
  document.head.appendChild(el);
}

const CSS = `
.sx-field{ display:flex; flex-direction:column; gap:6px; font-family:var(--font-body); }
.sx-field__label{ font-family:var(--font-display); font-weight:var(--fw-semibold); font-size:14px; color:var(--text-strong); }
.sx-field__hint{ font-size:12.5px; color:var(--text-muted); }
.sx-field__hint--error{ color:var(--danger-700); font-weight:600; }
.sx-input-wrap{ position:relative; display:flex; align-items:center; }
.sx-input-wrap__icon{ position:absolute; left:14px; display:inline-flex; color:var(--text-muted); pointer-events:none; }
.sx-input{
  width:100%; box-sizing:border-box; font-family:var(--font-body); font-weight:500; font-size:15px;
  color:var(--text-strong); background:var(--bg-surface);
  border:var(--border-2) solid var(--sand-400); border-radius:var(--radius-md);
  padding:11px 14px; transition:border-color .15s, box-shadow .15s;
}
.sx-input::placeholder{ color:var(--text-faint); }
.sx-input--has-icon{ padding-left:40px; }
.sx-input:hover{ border-color:var(--brown-300); }
.sx-input:focus{ outline:none; border-color:var(--ginger-500); box-shadow:var(--ring); }
.sx-input--error{ border-color:var(--danger-500); }
.sx-input--error:focus{ box-shadow:0 0 0 4px rgba(216,53,42,.25); }
.sx-input:disabled{ background:var(--cream-100); color:var(--text-muted); cursor:not-allowed; }
`;

export function Input({
  label, hint, error, icon = null, id, className = '', ...rest
}) {
  useStyleOnce('sx-input-css', CSS);
  const fid = id || (label ? 'sx-' + label.replace(/\s+/g, '-').toLowerCase() : undefined);
  const inputCls = ['sx-input', icon && 'sx-input--has-icon', error && 'sx-input--error', className]
    .filter(Boolean).join(' ');
  return (
    <div className="sx-field">
      {label && <label className="sx-field__label" htmlFor={fid}>{label}</label>}
      <div className="sx-input-wrap">
        {icon && <span className="sx-input-wrap__icon">{icon}</span>}
        <input id={fid} className={inputCls} {...rest} />
      </div>
      {error
        ? <span className="sx-field__hint sx-field__hint--error">{error}</span>
        : hint && <span className="sx-field__hint">{hint}</span>}
    </div>
  );
}
