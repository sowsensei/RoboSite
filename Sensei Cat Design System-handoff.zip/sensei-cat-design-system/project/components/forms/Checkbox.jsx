import React from 'react';

function useStyleOnce(id, css) {
  if (typeof document === 'undefined') return;
  if (document.getElementById(id)) return;
  const el = document.createElement('style'); el.id = id; el.textContent = css;
  document.head.appendChild(el);
}

const CSS = `
.sx-check{ display:inline-flex; align-items:flex-start; gap:10px; cursor:pointer; font-family:var(--font-body);
  font-weight:500; font-size:15px; color:var(--text-body); user-select:none; }
.sx-check input{ position:absolute; opacity:0; width:0; height:0; }
.sx-check__box{
  width:24px; height:24px; flex:none; border-radius:var(--radius-sm);
  background:var(--bg-surface); border:var(--border-2) solid var(--ink);
  display:inline-flex; align-items:center; justify-content:center;
  box-shadow:var(--pop-sm); transition:background .14s, box-shadow .08s, transform .08s;
}
.sx-check__box svg{ width:15px; height:15px; opacity:0; transform:scale(.5); transition:opacity .12s, transform .12s; }
.sx-check input:checked + .sx-check__box{ background:var(--ginger-500); }
.sx-check input:checked + .sx-check__box svg{ opacity:1; transform:scale(1); }
.sx-check:active .sx-check__box{ transform:translate(1px,1px); box-shadow:0 0 0; }
.sx-check input:focus-visible + .sx-check__box{ box-shadow:var(--pop-sm), var(--ring); }
.sx-check--disabled{ opacity:.5; cursor:not-allowed; }
`;

export function Checkbox({ checked, onChange, label, disabled = false, className = '', ...rest }) {
  useStyleOnce('sx-check-css', CSS);
  const cls = ['sx-check', disabled && 'sx-check--disabled', className].filter(Boolean).join(' ');
  return (
    <label className={cls}>
      <input type="checkbox" checked={checked} onChange={onChange} disabled={disabled} {...rest} />
      <span className="sx-check__box">
        <svg viewBox="0 0 24 24" fill="none" stroke="var(--ink)" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round">
          <path d="M5 12.5l4.5 4.5L19 6" />
        </svg>
      </span>
      {label && <span>{label}</span>}
    </label>
  );
}
