import * as React from 'react';

/**
 * Labelled text input with chunky outline, optional leading icon,
 * hint text and error state.
 */
export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  /** Field label above the input. */
  label?: string;
  /** Helper text below the input. */
  hint?: string;
  /** Error message — also turns the border red. */
  error?: string;
  /** Leading icon element. */
  icon?: React.ReactNode;
}

export function Input(props: InputProps): JSX.Element;
