import React from 'react';

function useStyleOnce(id, css) {
  if (typeof document === 'undefined') return;
  if (document.getElementById(id)) return;
  const el = document.createElement('style'); el.id = id; el.textContent = css;
  document.head.appendChild(el);
}

const CSS = `
.sx-switch{ display:inline-flex; align-items:center; gap:10px; cursor:pointer; font-family:var(--font-body);
  font-weight:600; font-size:14px; color:var(--text-strong); user-select:none; }
.sx-switch input{ position:absolute; opacity:0; width:0; height:0; }
.sx-switch__track{
  position:relative; width:46px; height:27px; border-radius:var(--radius-pill);
  background:var(--sand-400); border:var(--border-2) solid var(--ink);
  transition:background .18s ease; flex:none;
}
.sx-switch__thumb{
  position:absolute; top:1.5px; left:1.5px; width:20px; height:20px; border-radius:50%;
  background:var(--cream-50); border:var(--border-2) solid var(--ink);
  transition:transform .18s cubic-bezier(.34,1.56,.64,1);
}
.sx-switch input:checked + .sx-switch__track{ background:var(--ginger-500); }
.sx-switch input:checked + .sx-switch__track .sx-switch__thumb{ transform:translateX(19px); }
.sx-switch input:focus-visible + .sx-switch__track{ box-shadow:var(--ring); }
.sx-switch--disabled{ opacity:.5; cursor:not-allowed; }
`;

export function Switch({ checked, onChange, label, disabled = false, className = '', ...rest }) {
  useStyleOnce('sx-switch-css', CSS);
  const cls = ['sx-switch', disabled && 'sx-switch--disabled', className].filter(Boolean).join(' ');
  return (
    <label className={cls}>
      <input type="checkbox" checked={checked} onChange={onChange} disabled={disabled} {...rest} />
      <span className="sx-switch__track"><span className="sx-switch__thumb" /></span>
      {label && <span>{label}</span>}
    </label>
  );
}
