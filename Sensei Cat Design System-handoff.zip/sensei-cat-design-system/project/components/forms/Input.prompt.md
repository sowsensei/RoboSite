Labelled text input with chunky outline, optional leading icon, hint and error state.

```jsx
<Input label="Почта" type="email" placeholder="you@mail.ru" hint="Пришлём раз в неделю" />
<Input label="Никнейм" error="Уже занят" icon={<UserIcon/>} />
```
