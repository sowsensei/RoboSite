Sticker-style checkbox — hard pop shadow that presses on click, ginger fill when checked.

```jsx
<Checkbox checked={agree} onChange={e => setAgree(e.target.checked)} label="Согласен с правилами" />
```
