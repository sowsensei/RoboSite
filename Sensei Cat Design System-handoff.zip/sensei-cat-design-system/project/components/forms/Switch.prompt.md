Ink-outlined toggle with a springy thumb. Controlled via `checked` / `onChange`.

```jsx
<Switch checked={dark} onChange={e => setDark(e.target.checked)} label="Тёмная тема" />
```
