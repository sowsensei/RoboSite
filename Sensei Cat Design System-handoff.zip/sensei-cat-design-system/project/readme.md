# Сенсей — Рыжий кот · Design System

> Тёплая, дружелюбная, «комиксовая» система для бренда **Сенсей** — рыжего кота-наставника, который ведёт каналы и сайты про Dota 2, технику и спокойные победы.

This is the brand & UI design system for **Сенсей** (“Sensei”), a Russian-language gaming/tech content-creator brand built around a ginger-cat mascot. It exists to make every new site, landing, app screen, stream overlay or social asset feel like it belongs to the same warm, hand-outlined world as the mascot.

---

## 1. Context & sources

**What we were given:** only the mascot artwork — no codebase, no Figma, no existing product. The entire visual system below was derived *from the mascots* so it harmonises with them.

Source files (now in `assets/mascots/`):
- `sensei-master.png` — the wise **Сенсей**: ginger cat with a white beard, blue kimono, pointer & scroll, on a lavender halo. **This is the primary logo mark.**
- `sensei-phone.png` — the **Репортёр** mood: young cat in a cyan shirt + purple tie holding a phone. Used for “news / gadgets / app” contexts.
- `sensei-trophy.png` — the **Чемпион** mood: same cat lifting a Dota 2 trophy with confetti. Used for “wins / esports / support” contexts.

**Products represented (recreated as UI kits):**
1. **Channel website** — marketing/landing hub for the channel (`ui_kits/website/`).
2. **Додзё Сенсея** — a community/learning app: login → dashboard with feed, leaderboard, goals (`ui_kits/app/`).

> ⚠️ Both products are *invented* to demonstrate the system — there is no real codebase behind them. Treat the UI kits as the canonical reference for how the brand looks in product, not as a spec of a shipping app.

---

## 2. Content fundamentals — voice & tone

The Сенсей voice is **a calm, friendly mentor who happens to be a cat.** Warm, a little playful, never corporate, never condescending.

- **Language:** Russian-first. Headlines and UI are in Russian; Latin is fine for product/game names (Dota 2, Telegram).
- **Address:** informal **«ты»**, not «вы». We talk *with* the viewer, like a senpai who’s on your side. (“Учись у Сенсея”, “ты в ударе 5 дней подряд”.)
- **Tone:** encouraging + concrete. We promise *“без воды — только то, что работает.”* Praise the reader; celebrate streaks and wins.
- **Casing:** Sentence case for body and most headlines. **ALL CAPS** only for tiny eyebrows/labels and the wordmark `СЕНСЕЙ`. Avoid all-caps sentences.
- **Length:** short. Punchy headlines (3–6 words), one-line supporting sentences.
- **Emoji:** used **sparingly and warmly** — the paw 🐾 is the house emoji; 🏆 for wins. Never a wall of emoji, never as functional icons (use the icon set for that). One emoji per block, max.
- **Numbers & stats:** always in mono (`128K`, `2 480 XP`, `12:48`). Russian thousands use a thin/space separator (`14 920`).
- **Examples:**
  - Hero: *“Учись у Сенсея. Побеждай красиво.”*
  - CTA: *“Поддержи канал — расти вместе с нами.”*
  - Empty/again: *“Сенсей подготовил 3 новых разбора.”*
  - Microcopy: *“Войти в додзё”, “Напомнить”, “Продолжить обучение”.*

---

## 3. Visual foundations

The whole system is a **comic-sticker** language that mirrors the mascot’s thick dark-brown outlines and rounded, friendly shapes on warm paper.

### Colour
- Palette is sampled directly from the mascots. **Ginger `#FF8C1A`** is primary (the fur). Accents: **Lavender `#A98AD4`** (the halo), **Grape `#5B2E9D`** (the tie), **Cyan `#00A6CE`** (the shirt), **Gold `#FFC94D`** (scroll/trophy), **Coral `#F47B6A`** (nose/cheeks).
- **Brown ink `#2E1A0E`** is the universal outline + darkest text — it is the “comic stroke”. Text on warm **cream** (`#FFFBF2` page, `#FBF3E4` panels).
- Dark sections invert onto **ink** with cream text (footer, “upcoming stream” card).
- Semantic: success green, **danger = the Dota red `#D8352A`**, warning gold, info cyan.
- Vibe of imagery: **warm, saturated, friendly cartoon** — never cold, never grayscale, never photographic. All illustration shares the same heavy outline + soft cel-shading.

### Type
- **Display/heading: Rubik** (700–900) — chunky, rounded, full Cyrillic. Tight tracking (−0.02em), `text-wrap: balance`.
- **Body: Nunito** (400–800) — rounded, warm, very readable Cyrillic.
- **Mono: JetBrains Mono** — stats, XP, timestamps, code, counters.
- Minimum body 14px; eyebrows are 12–13px uppercase with `0.08em` tracking in ginger.

### Shape, border, elevation
- **Corners are rounded and generous** (md 14 / lg 20 / xl 28 / pill) — echoing the round-cheeked cat.
- **Two elevation systems:**
  - *Soft* warm shadows (`--shadow-*`) for calm surfaces.
  - **Pop / sticker** — hard offset ink shadows (`--pop`, `2–9px 0 ink`) on ink-outlined elements. This is the signature look on buttons, primary cards, badges, inputs.
- **Borders:** the comic stroke is `--border-2` (2.5px) ink. Soft sand borders (`--border-soft`) for quiet panels.

### Motion & states
- **Hover:** sticker elements nudge up-left (`translate(-1px,-1px)`) and the pop shadow grows.
- **Press/active:** the element *presses into* its shadow (`translate(2px,2px)`, shadow → 0) — a physical, tactile “stamp”. Switches/checkboxes use a springy `cubic-bezier(.34,1.56,.64,1)` thumb.
- **Easing:** quick (80ms) for press, 150ms for colour. No long fades, no parallax. `live` badges pulse gently (1.4s).
- Respect `prefers-reduced-motion` for any entrance animation.

### Layout & motifs
- Container max 1200px; 4px spacing grid; section rhythm ~96px.
- **Lavender halo** (`.sensei-halo`) behind the mascot/avatars — the mascot’s own backdrop, reused as a motif.
- **Whisker rule** — a dashed sand divider (`.sensei-rule`).
- **Floating sticker chips** over the hero mascot (live, stats) — ink-outlined pills with pop shadow.
- Transparency/blur: used only for sticky headers (cream at 86% + blur). Surfaces themselves are opaque paper.

---

## 4. Iconography

- **Style:** Lucide-style **line icons** — 24px grid, **2px stroke, round caps & joins**, `currentColor`. They sit comfortably next to the heavier mascot outline without competing.
- **Where they live:** `ui_kits/website/Icons.jsx` exports the working set (`IconPlay, IconBell, IconSend, IconSearch, IconHome, IconFire, IconVideo, IconTrophy, IconUsers, IconStar, IconClock, IconEye, IconHeart, IconSettings, …`). The app kit imports the same set so glyphs stay consistent across products.
- **Substitution note:** these are hand-built to match **[Lucide](https://lucide.dev)** geometry. For production, install `lucide-react` and use it directly — the names map 1:1. ⚠️ This is the one substitution in the system (no icon font was provided).
- **Filled vs line:** mostly line. A few accent glyphs render filled (`IconPlay`, `IconStar fill`) inside chips/buttons.
- **Emoji** are content, not icons — see voice section (🐾 / 🏆 only, sparingly).
- **No hand-drawn decorative SVG.** Illustration = the mascot PNGs only.

---

## 5. File index / manifest

```
styles.css              ← global entry (consumers link THIS). @import manifest only.
tokens/
  fonts.css             Google Fonts @import (Rubik, Nunito, JetBrains Mono)
  colors.css            full palette + semantic aliases
  typography.css        families, weights, scale, leading, tracking
  spacing.css           4px grid + layout rhythm
  radii.css             corner radii + comic border widths
  shadows.css           soft + pop(sticker) elevation, focus ring
  base.css              light resets + brand helpers (.sensei-halo/.sensei-sticker/.sensei-eyebrow/.sensei-rule)
assets/mascots/         sensei-master / -phone / -trophy .png  (master = logo)
guidelines/foundations/ specimen cards (Colors / Type / Spacing / Brand) → Design System tab
components/
  core/        Button · Badge · Tag · Card · Avatar
  forms/       Input · Switch · Checkbox
  navigation/  Tabs
  feedback/    ProgressBar
ui_kits/
  website/     Channel landing — SiteHeader, Hero, VideoGrid, SupportCTA, SiteFooter (+ Icons)
  app/         Додзё Сенсея — LoginScreen, AppShell(Sidebar, TopBar, Dashboard)
SKILL.md       Agent-Skill manifest for downloading into Claude Code
```

**Components** (React, `window.SenseiCatDesignSystem_<hash>.<Name>`): Button, Badge, Tag, Card, Avatar, Input, Switch, Checkbox, Tabs, ProgressBar. Each has a `.d.ts` (props) and `.prompt.md` (usage).

**Starting points:** Button (component); plus screens — Website landing, App login, App dashboard.

---

## 6. How to use
- **Product code:** link `styles.css`, build with the tokens and the React components.
- **Throwaway artifacts (slides, mocks, social):** copy mascot PNGs out of `assets/`, use the tokens/CSS, and lean on the sticker motifs. Keep the voice warm and informal.
- Always reach for **semantic aliases** (`--brand`, `--text-body`, `--surface…`) before raw scale values.
