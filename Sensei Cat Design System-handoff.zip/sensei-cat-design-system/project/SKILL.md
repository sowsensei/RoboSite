---
name: sensei-design
description: Use this skill to generate well-branded interfaces and assets for Сенсей (Sensei, the ginger-cat content-creator brand), either for production or throwaway prototypes/mocks/decks. Contains essential design guidelines, colors, type, fonts, mascot assets, and UI kit components for prototyping.
user-invocable: true
---

Read the `readme.md` file within this skill, and explore the other available files.

This is the **Сенсей — Рыжий кот** design system: a warm, comic-sticker visual language built around a ginger-cat mascot for a Russian-language gaming/tech channel & community.

Quick orientation:
- **Tokens & global CSS:** `styles.css` (entry) → `tokens/*.css`. Link `styles.css` and use the CSS custom properties (`--brand`, `--ink`, `--pop`, etc.).
- **Mascots:** `assets/mascots/` — `sensei-master.png` (logo / wise sensei), `sensei-phone.png` (news/app), `sensei-trophy.png` (wins/support).
- **Components:** `components/{core,forms,navigation,feedback}/` — React, ink-outlined “sticker” style. Each `<Name>.jsx` has a `<Name>.d.ts` + `<Name>.prompt.md`.
- **UI kits:** `ui_kits/website/` (channel landing) and `ui_kits/app/` (Додзё dashboard + login) show the brand in product.
- **Voice:** Russian, informal «ты», warm and encouraging, sentence case, mono for numbers, 🐾 used sparingly. See readme §2.

If creating visual artifacts (slides, mocks, throwaway prototypes, social cards): copy the mascot PNGs out and produce static HTML files for the user to view, using the tokens and the comic-sticker motifs (ink outlines, hard pop shadows, lavender halo, rounded corners, cream paper).

If working on production code: copy assets and read the rules here to become an expert designing with this brand.

If the user invokes this skill without other guidance, ask what they want to build or design, ask a few focused questions, then act as an expert designer who outputs HTML artifacts *or* production code, depending on the need.
