import React from 'react';
import { IconSend, IconVideo, IconHeart } from './Icons.jsx';

const COLS = [
  { h: 'Канал', items: ['Видео', 'Стримы', 'Гайды', 'Плейлисты'] },
  { h: 'Сообщество', items: ['Telegram', 'Discord', 'Чат', 'Правила'] },
  { h: 'Ещё', items: ['Магазин', 'Реклама', 'Пресса', 'Контакты'] },
];

export function SiteFooter() {
  return (
    <footer style={{ background: 'var(--ink)', color: 'var(--cream-100)', borderTop: '3px solid var(--ink)' }}>
      <div style={{
        maxWidth: 'var(--container-max)', margin: '0 auto', padding: '56px 24px 28px',
        display: 'grid', gridTemplateColumns: '1.6fr 1fr 1fr 1fr', gap: 32,
      }} className="sx-footer-grid">
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
            <img src="../../assets/mascots/sensei-master.png" alt="" style={{ width: 46, height: 46, objectFit: 'contain' }} />
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 24 }}>
              СЕН<span style={{ color: 'var(--ginger-400)' }}>СЕЙ</span>
            </span>
          </div>
          <p style={{ color: 'var(--sand-300)', fontSize: 14.5, maxWidth: '34ch', lineHeight: 1.6 }}>
            Рыжий кот-наставник про Dota&nbsp;2, технику и спокойные победы. Заходи в додзё.
          </p>
          <div style={{ display: 'flex', gap: 10, marginTop: 18 }}>
            {[<IconSend size={18} />, <IconVideo size={18} />, <IconHeart size={18} />].map((ic, i) => (
              <span key={i} style={{
                width: 40, height: 40, display: 'grid', placeItems: 'center',
                background: 'rgba(255,251,242,0.08)', border: '2px solid rgba(255,251,242,0.18)',
                borderRadius: 'var(--radius-md)', color: 'var(--cream-50)',
              }}>{ic}</span>
            ))}
          </div>
        </div>
        {COLS.map((c) => (
          <div key={c.h}>
            <h4 style={{
              fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 13, letterSpacing: '0.1em',
              textTransform: 'uppercase', color: 'var(--ginger-400)', margin: '0 0 14px',
            }}>{c.h}</h4>
            <ul style={{ listStyle: 'none', margin: 0, padding: 0, display: 'flex', flexDirection: 'column', gap: 9 }}>
              {c.items.map((it) => (
                <li key={it}><a href="#" style={{ color: 'var(--sand-300)', fontSize: 14.5, fontWeight: 600, textDecoration: 'none' }}>{it}</a></li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div style={{
        maxWidth: 'var(--container-max)', margin: '0 auto', padding: '18px 24px 40px',
        borderTop: '1px solid rgba(255,251,242,0.12)', display: 'flex', justifyContent: 'space-between',
        gap: 16, flexWrap: 'wrap', color: 'var(--sand-400)', fontSize: 13,
      }}>
        <span>© 2026 Сенсей · Рыжий кот дизайн</span>
        <span style={{ fontFamily: 'var(--font-mono)' }}>Сделано с теплом 🐾</span>
      </div>
    </footer>
  );
}
