import React from 'react';
import { Button } from '../../components/core/Button.jsx';
import { ProgressBar } from '../../components/feedback/ProgressBar.jsx';
import { IconHeart, IconSend } from './Icons.jsx';

export function SupportCTA() {
  return (
    <section style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '0 24px 80px' }}>
      <div style={{
        position: 'relative', overflow: 'hidden',
        background: 'var(--lavender-200)', border: '3px solid var(--ink)',
        borderRadius: 'var(--radius-2xl)', boxShadow: 'var(--pop-lg)',
        display: 'grid', gridTemplateColumns: '1.4fr 0.9fr', gap: 24, alignItems: 'center',
        padding: '40px 44px',
      }} className="sx-cta">
        <div>
          <span className="sensei-eyebrow" style={{ color: 'var(--grape-600)' }}>Додзё Сенсея</span>
          <h2 style={{ fontSize: 38, margin: '10px 0 12px' }}>Поддержи канал — расти вместе с нами</h2>
          <p style={{ fontSize: 17, color: 'var(--brown-700)', maxWidth: '48ch', marginBottom: 22 }}>
            Закрытые стримы, гайды раньше всех и тёплый чат. Помоги Сенсею собрать на новую студию.
          </p>
          <div style={{ maxWidth: 460, marginBottom: 24 }}>
            <ProgressBar label="Цель: новая студия" value={128} max={200} tone="ginger" />
          </div>
          <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
            <Button size="lg" variant="accent" iconLeft={<IconHeart size={18} />}>Поддержать</Button>
            <Button size="lg" variant="secondary" iconLeft={<IconSend size={18} />}>В Telegram</Button>
          </div>
        </div>
        <div style={{ position: 'relative', display: 'grid', placeItems: 'center', minHeight: 240 }}>
          <img src="../../assets/mascots/sensei-trophy.png" alt="" style={{
            width: 'min(280px, 100%)', objectFit: 'contain',
            filter: 'drop-shadow(0 16px 22px rgba(46,26,14,0.28))',
          }} />
        </div>
      </div>
    </section>
  );
}
