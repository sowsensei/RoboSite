import React from 'react';
import { Button } from '../../components/core/Button.jsx';
import { IconBell, IconSearch, IconMenu } from './Icons.jsx';

const NAV = ['Видео', 'Стримы', 'Гайды', 'Магазин', 'О канале'];

export function SiteHeader({ onSubscribe }) {
  return (
    <header style={{
      position: 'sticky', top: 0, zIndex: 20,
      background: 'rgba(255,251,242,0.86)', backdropFilter: 'blur(10px)',
      borderBottom: '2.5px solid var(--ink)',
    }}>
      <div style={{
        maxWidth: 'var(--container-max)', margin: '0 auto', padding: '12px 24px',
        display: 'flex', alignItems: 'center', gap: 24,
      }}>
        {/* logo */}
        <a href="#" style={{ display: 'flex', alignItems: 'center', gap: 10, textDecoration: 'none' }}>
          <span className="sensei-halo" style={{ width: 44, height: 44, display: 'grid', placeItems: 'center' }}>
            <img src="../../assets/mascots/sensei-master.png" alt="Сенсей" style={{ width: 44, height: 44, objectFit: 'contain' }} />
          </span>
          <span style={{
            fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 24, letterSpacing: '-0.02em',
            color: 'var(--text-strong)',
          }}>СЕН<span style={{ color: 'var(--brand)' }}>СЕЙ</span></span>
        </a>

        <nav style={{ display: 'flex', gap: 4, marginLeft: 8 }} className="sx-nav">
          {NAV.map((n, i) => (
            <a key={n} href="#" style={{
              fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15,
              color: i === 0 ? 'var(--ginger-700)' : 'var(--brown-700)',
              padding: '8px 12px', borderRadius: 'var(--radius-pill)', textDecoration: 'none',
            }}>{n}</a>
          ))}
        </nav>

        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 10 }}>
          <button className="sx-icon-btn" aria-label="Поиск"><IconSearch size={20} /></button>
          <button className="sx-icon-btn" aria-label="Уведомления"><IconBell size={20} /></button>
          <Button variant="primary" size="sm" iconLeft={<IconBell size={15} />} onClick={onSubscribe}>Подписаться</Button>
          <button className="sx-icon-btn sx-only-mobile" aria-label="Меню"><IconMenu size={22} /></button>
        </div>
      </div>
    </header>
  );
}
