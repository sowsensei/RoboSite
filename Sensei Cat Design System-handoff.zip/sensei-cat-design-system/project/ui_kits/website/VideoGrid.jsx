import React from 'react';
import { Card } from '../../components/core/Card.jsx';
import { Badge } from '../../components/core/Badge.jsx';
import { Tabs } from '../../components/navigation/Tabs.jsx';
import { IconPlay, IconEye, IconClock } from './Icons.jsx';

const VIDEOS = [
  { t: 'Как Сенсей собрал ПК за 80К', cat: 'Железо', tone: 'cyan',   bg: 'var(--cyan-200)',     dur: '14:22', views: '84K', when: '2 дня назад', live: false },
  { t: 'Разбор: почему ты сливаешь миды', cat: 'Dota 2', tone: 'ginger', bg: 'var(--ginger-200)', dur: '21:08', views: '212K', when: '5 дней назад', live: false },
  { t: 'Стрим: ранкеды до рассвета', cat: 'Стрим', tone: 'live', bg: 'var(--grape-500)',  dur: 'LIVE', views: '3.1K', when: 'сейчас', live: true },
  { t: 'ТОП-5 наушников 2026 года', cat: 'Гаджеты', tone: 'grape', bg: 'var(--lavender-200)', dur: '11:40', views: '63K', when: 'неделю назад', live: false },
  { t: 'Гайд новичку: первые 100 часов', cat: 'Гайд', tone: 'ginger', bg: 'var(--gold-300)', dur: '18:55', views: '128K', when: '2 недели назад', live: false },
  { t: 'Реакция на патч 7.40', cat: 'Dota 2', tone: 'cyan', bg: 'var(--cyan-100)', dur: '09:30', views: '47K', when: '3 недели назад', live: false },
];

const TABS = [
  { id: 'all', label: 'Все' }, { id: 'dota', label: 'Dota 2' },
  { id: 'tech', label: 'Техника' }, { id: 'streams', label: 'Стримы' },
];

function Thumb({ v }) {
  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', background: v.bg, display: 'grid', placeItems: 'center' }}>
      <span style={{
        fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 13, letterSpacing: '0.14em',
        textTransform: 'uppercase', color: 'rgba(46,26,14,0.30)',
      }}>СЕНСЕЙ</span>
      {/* play button */}
      <span style={{
        position: 'absolute', width: 52, height: 52, display: 'grid', placeItems: 'center',
        background: 'var(--bg-surface)', color: 'var(--ginger-600)',
        border: '2.5px solid var(--ink)', borderRadius: '50%', boxShadow: 'var(--pop-sm)',
      }}><IconPlay size={20} /></span>
      <span style={{ position: 'absolute', left: 10, top: 10 }}>
        <Badge tone={v.live ? 'live' : 'neutral'} dot={v.live}>{v.live ? 'В ЭФИРЕ' : v.cat}</Badge>
      </span>
      <span style={{
        position: 'absolute', right: 10, bottom: 10, fontFamily: 'var(--font-mono)', fontWeight: 700,
        fontSize: 12, color: '#fff', background: 'rgba(46,26,14,0.82)', padding: '3px 8px',
        borderRadius: 'var(--radius-sm)',
      }}>{v.dur}</span>
    </div>
  );
}

export function VideoGrid() {
  const [tab, setTab] = React.useState('all');
  return (
    <section style={{ maxWidth: 'var(--container-max)', margin: '0 auto', padding: '24px 24px 72px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16, marginBottom: 24, flexWrap: 'wrap' }}>
        <h2 style={{ fontSize: 34, margin: 0 }}>Свежие ролики</h2>
        <Tabs tabs={TABS} value={tab} onChange={setTab} />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: 22 }}>
        {VIDEOS.map((v, i) => (
          <Card key={i} variant="sticker" interactive media={<Thumb v={v} />}>
            <h3 style={{ fontSize: 18, margin: '2px 0 0', lineHeight: 1.18 }}>{v.t}</h3>
            <div style={{ display: 'flex', alignItems: 'center', gap: 14, color: 'var(--text-muted)', fontSize: 13, fontWeight: 600, marginTop: 4 }}>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}><IconEye size={15} />{v.views}</span>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}><IconClock size={15} />{v.when}</span>
            </div>
          </Card>
        ))}
      </div>
    </section>
  );
}
