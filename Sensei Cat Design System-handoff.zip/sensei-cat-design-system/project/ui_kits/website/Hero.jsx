import React from 'react';
import { Button } from '../../components/core/Button.jsx';
import { Badge } from '../../components/core/Badge.jsx';
import { IconPlay, IconSend, IconUsers, IconEye } from './Icons.jsx';

export function Hero() {
  return (
    <section style={{ position: 'relative', overflow: 'hidden' }}>
      {/* soft lavender wash */}
      <div style={{
        position: 'absolute', inset: 0, zIndex: 0,
        background: 'radial-gradient(900px 520px at 78% 30%, var(--lavender-100), transparent 60%)',
      }} />
      <div style={{
        position: 'relative', zIndex: 1, maxWidth: 'var(--container-max)', margin: '0 auto',
        padding: '64px 24px 72px', display: 'grid', gridTemplateColumns: '1.05fr 0.95fr',
        gap: 32, alignItems: 'center',
      }} className="sx-hero-grid">
        {/* copy */}
        <div>
          <span className="sensei-eyebrow">Рыжий кот · дизайн</span>
          <h1 style={{ fontSize: 'clamp(40px, 6vw, 72px)', margin: '12px 0 18px', lineHeight: 0.98 }}>
            Учись у&nbsp;<span style={{ color: 'var(--brand)' }}>Сенсея</span>.<br />Побеждай красиво.
          </h1>
          <p style={{ fontSize: 19, color: 'var(--text-body)', maxWidth: '46ch', marginBottom: 28 }}>
            Разборы матчей Dota&nbsp;2, обзоры техники и спокойные гайды от рыжего кота-наставника.
            Без воды — только то, что работает.
          </p>
          <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
            <Button size="lg" iconLeft={<IconPlay size={18} />}>Смотреть свежее</Button>
            <Button size="lg" variant="cool" iconLeft={<IconSend size={18} />}>Telegram-канал</Button>
          </div>
          <div style={{ display: 'flex', gap: 28, marginTop: 34, flexWrap: 'wrap' }}>
            <Stat icon={<IconUsers size={18} />} value="128K" label="подписчиков" />
            <Stat icon={<IconEye size={18} />} value="24M" label="просмотров" />
            <Stat icon={<IconPlay size={18} />} value="340+" label="роликов" />
          </div>
        </div>

        {/* mascot */}
        <div style={{ position: 'relative', display: 'grid', placeItems: 'center', minHeight: 420 }}>
          <div className="sensei-halo" style={{ width: 'min(440px, 90%)', aspectRatio: '1', display: 'grid', placeItems: 'center' }}>
            <img src="../../assets/mascots/sensei-master.png" alt="Сенсей" style={{
              width: '100%', height: '100%', objectFit: 'contain',
              filter: 'drop-shadow(0 18px 26px rgba(46,26,14,0.22))',
            }} />
          </div>
          <FloatChip style={{ top: '8%', left: '2%' }}><Badge tone="live" dot>В ЭФИРЕ</Badge></FloatChip>
          <FloatChip style={{ bottom: '12%', right: '0%' }}>
            <span style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 14 }}>🏆 1-е место</span>
          </FloatChip>
          <FloatChip style={{ top: '20%', right: '4%' }}>
            <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 13, color: 'var(--ginger-700)' }}>+2.4K сегодня</span>
          </FloatChip>
        </div>
      </div>
    </section>
  );
}

function Stat({ icon, value, label }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
      <span style={{
        width: 38, height: 38, display: 'grid', placeItems: 'center', flex: 'none',
        background: 'var(--ginger-100)', color: 'var(--ginger-700)',
        border: '2px solid var(--ink)', borderRadius: 'var(--radius-md)',
      }}>{icon}</span>
      <div style={{ lineHeight: 1.05 }}>
        <div style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 20, color: 'var(--text-strong)' }}>{value}</div>
        <div style={{ fontSize: 13, color: 'var(--text-muted)', fontWeight: 600 }}>{label}</div>
      </div>
    </div>
  );
}

function FloatChip({ children, style }) {
  return (
    <div style={{
      position: 'absolute', background: 'var(--bg-surface)', border: '2.5px solid var(--ink)',
      borderRadius: 'var(--radius-pill)', boxShadow: 'var(--pop)', padding: '8px 14px',
      ...style,
    }}>{children}</div>
  );
}
