import React from 'react';
import { Button } from '../../components/core/Button.jsx';
import { Input } from '../../components/forms/Input.jsx';
import { Checkbox } from '../../components/forms/Checkbox.jsx';
import { IconSend } from '../website/Icons.jsx';

export function LoginScreen({ onLogin }) {
  const [remember, setRemember] = React.useState(true);
  return (
    <div style={{ minHeight: '100vh', display: 'grid', gridTemplateColumns: '1fr 1fr', background: 'var(--bg-page)' }} className="sx-auth">
      {/* brand side */}
      <div style={{
        position: 'relative', overflow: 'hidden', display: 'grid', placeItems: 'center', padding: 40,
        background: 'radial-gradient(700px 500px at 50% 30%, var(--lavender-300), var(--grape-600))',
        borderRight: '3px solid var(--ink)',
      }} className="sx-auth-brand">
        <div style={{ textAlign: 'center', maxWidth: 380 }}>
          <img src="../../assets/mascots/sensei-master.png" alt="Сенсей" style={{ width: 220, objectFit: 'contain', filter: 'drop-shadow(0 16px 24px rgba(46,26,14,0.32))' }} />
          <h2 style={{ color: 'var(--cream-50)', fontSize: 30, margin: '18px 0 10px' }}>Добро пожаловать в додзё</h2>
          <p style={{ color: 'var(--lavender-100)', fontSize: 16, margin: 0 }}>
            Учись у Сенсея, поднимай ранг и тащи катки. Тёплое комьюнити уже ждёт.
          </p>
        </div>
      </div>

      {/* form side */}
      <div style={{ display: 'grid', placeItems: 'center', padding: 40 }}>
        <div style={{ width: '100%', maxWidth: 380 }}>
          <span className="sensei-eyebrow">Рыжий кот · дизайн</span>
          <h1 style={{ fontSize: 38, margin: '10px 0 6px' }}>С возвращением!</h1>
          <p style={{ color: 'var(--text-muted)', margin: '0 0 26px', fontSize: 15.5 }}>Войди, чтобы продолжить обучение.</p>

          <form onSubmit={(e) => { e.preventDefault(); onLogin && onLogin(); }} style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
            <Input label="Почта" type="email" placeholder="you@mail.ru" defaultValue="ivan@kot.ru" />
            <Input label="Пароль" type="password" placeholder="••••••••" defaultValue="murmur" />
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <Checkbox checked={remember} onChange={(e) => setRemember(e.target.checked)} label="Запомнить меня" />
              <a href="#" style={{ fontSize: 14, fontWeight: 700, color: 'var(--text-link)' }}>Забыли?</a>
            </div>
            <Button type="submit" size="lg" fullWidth>Войти в додзё</Button>
            <Button type="button" variant="secondary" size="lg" fullWidth iconLeft={<IconSend size={18} />} onClick={onLogin}>Войти через Telegram</Button>
          </form>

          <p style={{ textAlign: 'center', marginTop: 22, fontSize: 14.5, color: 'var(--text-muted)' }}>
            Нет аккаунта? <a href="#" style={{ fontWeight: 800, color: 'var(--ginger-700)' }}>Создать</a>
          </p>
        </div>
      </div>
    </div>
  );
}
