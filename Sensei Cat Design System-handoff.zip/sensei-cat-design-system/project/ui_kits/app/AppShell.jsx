import React from 'react';
import { Sidebar } from './Sidebar.jsx';
import { TopBar } from './TopBar.jsx';
import { Dashboard } from './Dashboard.jsx';

const TITLES = { home: 'Главная', feed: 'Лента', streams: 'Стримы', tournaments: 'Турниры', community: 'Додзё' };

export function AppShell() {
  const [active, setActive] = React.useState('home');
  return (
    <div style={{ display: 'flex', minHeight: '100vh', background: 'var(--bg-page)' }}>
      <Sidebar active={active} onNavigate={setActive} />
      <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        <TopBar title={TITLES[active] || 'Главная'} />
        <main style={{ flex: 1, overflow: 'auto' }}>
          <Dashboard />
        </main>
      </div>
    </div>
  );
}
