import React from 'react';
import { Avatar } from '../../components/core/Avatar.jsx';
import { IconSearch, IconBell, IconStar } from '../website/Icons.jsx';

export function TopBar({ title = 'Главная' }) {
  return (
    <header style={{
      height: 70, flex: 'none', display: 'flex', alignItems: 'center', gap: 18,
      padding: '0 28px', background: 'rgba(255,251,242,0.86)', backdropFilter: 'blur(8px)',
      borderBottom: '2.5px solid var(--ink)', position: 'sticky', top: 0, zIndex: 10,
    }}>
      <h1 style={{ fontSize: 24, margin: 0 }}>{title}</h1>

      <label style={{
        marginLeft: 18, display: 'flex', alignItems: 'center', gap: 10, flex: 1, maxWidth: 420,
        background: 'var(--bg-surface)', border: '2.5px solid var(--sand-400)',
        borderRadius: 'var(--radius-pill)', padding: '9px 16px', color: 'var(--text-muted)',
      }} className="sx-search">
        <IconSearch size={18} />
        <input placeholder="Искать гайды, стримы, людей…" style={{
          border: 'none', outline: 'none', background: 'transparent', flex: 1,
          fontFamily: 'var(--font-body)', fontSize: 14.5, fontWeight: 600, color: 'var(--text-strong)',
        }} />
      </label>

      <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 14 }}>
        {/* XP pill */}
        <div style={{
          display: 'flex', alignItems: 'center', gap: 8, padding: '7px 14px',
          background: 'var(--gold-300)', border: '2.5px solid var(--ink)', borderRadius: 'var(--radius-pill)',
          boxShadow: 'var(--pop-sm)', color: 'var(--ink)',
        }} className="sx-xp">
          <span style={{ color: 'var(--gold-700)' }}><IconStar size={17} fill /></span>
          <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 14 }}>2 480 XP</span>
        </div>
        <button className="sx-icon-btn" aria-label="Уведомления" style={{ position: 'relative' }}>
          <IconBell size={20} />
          <span style={{ position: 'absolute', top: 7, right: 8, width: 9, height: 9, background: 'var(--danger-500)', border: '2px solid var(--bg-surface)', borderRadius: '50%' }} />
        </button>
        <Avatar name="Иван Котов" size="md" online />
      </div>
    </header>
  );
}
