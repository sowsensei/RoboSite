import React from 'react';
import { Avatar } from '../../components/core/Avatar.jsx';
import { Badge } from '../../components/core/Badge.jsx';
import { IconHome, IconFire, IconVideo, IconTrophy, IconUsers, IconSettings } from '../website/Icons.jsx';

const NAV = [
  { id: 'home', label: 'Главная', icon: IconHome },
  { id: 'feed', label: 'Лента', icon: IconFire },
  { id: 'streams', label: 'Стримы', icon: IconVideo, badge: 'LIVE' },
  { id: 'tournaments', label: 'Турниры', icon: IconTrophy },
  { id: 'community', label: 'Додзё', icon: IconUsers },
];

export function Sidebar({ active = 'home', onNavigate }) {
  return (
    <aside style={{
      width: 248, flex: 'none', background: 'var(--bg-surface)', borderRight: '2.5px solid var(--ink)',
      display: 'flex', flexDirection: 'column', padding: '20px 16px', gap: 6, minHeight: '100%',
    }} className="sx-sidebar">
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '0 6px 14px' }}>
        <img src="../../assets/mascots/sensei-master.png" alt="" style={{ width: 40, height: 40, objectFit: 'contain' }} />
        <span style={{ fontFamily: 'var(--font-display)', fontWeight: 900, fontSize: 21, color: 'var(--text-strong)' }}>
          СЕН<span style={{ color: 'var(--brand)' }}>СЕЙ</span>
        </span>
      </div>

      <nav style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        {NAV.map((n) => {
          const Ic = n.icon; const on = n.id === active;
          return (
            <button key={n.id} onClick={() => onNavigate && onNavigate(n.id)} style={{
              display: 'flex', alignItems: 'center', gap: 12, padding: '11px 12px', cursor: 'pointer',
              fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, textAlign: 'left',
              color: on ? 'var(--text-on-brand)' : 'var(--brown-700)',
              background: on ? 'var(--ginger-500)' : 'transparent',
              border: on ? '2.5px solid var(--ink)' : '2.5px solid transparent',
              borderRadius: 'var(--radius-md)', boxShadow: on ? 'var(--pop-sm)' : 'none',
            }}>
              <Ic size={20} />
              <span style={{ flex: 1 }}>{n.label}</span>
              {n.badge && <Badge tone="live" dot>{n.badge}</Badge>}
            </button>
          );
        })}
      </nav>

      <div style={{ marginTop: 'auto', display: 'flex', flexDirection: 'column', gap: 4 }}>
        <button style={navGhost}><IconSettings size={20} /><span>Настройки</span></button>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10, padding: '10px', marginTop: 6,
          background: 'var(--cream-100)', border: '2px solid var(--sand-300)', borderRadius: 'var(--radius-lg)',
        }}>
          <Avatar name="Иван Котов" size="sm" online />
          <div style={{ lineHeight: 1.1, minWidth: 0 }}>
            <div style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 14, color: 'var(--text-strong)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>Иван Котов</div>
            <div style={{ fontSize: 12, color: 'var(--text-muted)', fontWeight: 600 }}>Ученик · 7 ур.</div>
          </div>
        </div>
      </div>
    </aside>
  );
}

const navGhost = {
  display: 'flex', alignItems: 'center', gap: 12, padding: '11px 12px', cursor: 'pointer',
  fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 15, textAlign: 'left',
  color: 'var(--brown-700)', background: 'transparent', border: '2.5px solid transparent',
  borderRadius: 'var(--radius-md)',
};
