import React from 'react';
import { Card } from '../../components/core/Card.jsx';
import { Badge } from '../../components/core/Badge.jsx';
import { Button } from '../../components/core/Button.jsx';
import { Avatar } from '../../components/core/Avatar.jsx';
import { ProgressBar } from '../../components/feedback/ProgressBar.jsx';
import { Tabs } from '../../components/navigation/Tabs.jsx';
import { IconPlay, IconTrophy, IconClock, IconStar } from '../website/Icons.jsx';

const CONTINUE = [
  { t: 'Тайминги Roshan', sub: 'Гайд · 12 мин', p: 64, bg: 'var(--cyan-200)' },
  { t: 'Сборка на Invoker', sub: 'Разбор · 24 мин', p: 30, bg: 'var(--ginger-200)' },
  { t: 'Вард-контроль', sub: 'Урок · 9 мин', p: 88, bg: 'var(--lavender-200)' },
];

const BOARD = [
  { n: 'KittyMid', xp: '14 920', d: true },
  { n: 'rawr_pro', xp: '12 340' },
  { n: 'Иван Котов', xp: '9 880', me: true },
  { n: 'sunsetcat', xp: '8 410' },
];

export function Dashboard() {
  const [tab, setTab] = React.useState('week');
  return (
    <div style={{ padding: 28, display: 'grid', gridTemplateColumns: 'minmax(0,1fr) 320px', gap: 24, alignItems: 'start' }} className="sx-dash">
      {/* main column */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 24, minWidth: 0 }}>
        {/* welcome banner */}
        <div style={{
          position: 'relative', overflow: 'hidden', display: 'grid', gridTemplateColumns: '1fr auto',
          gap: 16, alignItems: 'center', padding: '26px 28px',
          background: 'linear-gradient(120deg, var(--ginger-100), var(--lavender-100))',
          border: '3px solid var(--ink)', borderRadius: 'var(--radius-2xl)', boxShadow: 'var(--pop)',
        }}>
          <div>
            <span className="sensei-eyebrow">С возвращением</span>
            <h2 style={{ fontSize: 30, margin: '8px 0 6px' }}>Привет, Иван! 🐾</h2>
            <p style={{ fontSize: 16, color: 'var(--brown-700)', margin: '0 0 18px', maxWidth: '44ch' }}>
              Сенсей подготовил 3 новых разбора. Продолжай серию — ты в ударе 5 дней подряд.
            </p>
            <Button iconLeft={<IconPlay size={16} />}>Продолжить обучение</Button>
          </div>
          <img src="../../assets/mascots/sensei-phone.png" alt="" style={{ width: 150, objectFit: 'contain', filter: 'drop-shadow(0 12px 18px rgba(46,26,14,0.22))' }} className="sx-hide-sm" />
        </div>

        {/* continue watching */}
        <section>
          <h3 style={{ fontSize: 20, margin: '0 0 14px' }}>Продолжить просмотр</h3>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(190px,1fr))', gap: 16 }}>
            {CONTINUE.map((c, i) => (
              <Card key={i} variant="sticker" interactive media={
                <div style={{ position: 'relative', height: '100%', background: c.bg, display: 'grid', placeItems: 'center' }}>
                  <span style={{ width: 46, height: 46, display: 'grid', placeItems: 'center', background: 'var(--bg-surface)', color: 'var(--ginger-600)', border: '2.5px solid var(--ink)', borderRadius: '50%', boxShadow: 'var(--pop-sm)' }}><IconPlay size={18} /></span>
                </div>
              }>
                <h4 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 15, margin: '0 0 8px', color: 'var(--text-strong)' }}>{c.t}</h4>
                <ProgressBar value={c.p} max={100} showValue={false} tone={i === 1 ? 'cyan' : 'ginger'} />
                <span style={{ fontSize: 12.5, color: 'var(--text-muted)', fontWeight: 600, marginTop: 6 }}>{c.sub}</span>
              </Card>
            ))}
          </div>
        </section>
      </div>

      {/* right rail */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }} className="sx-rail">
        <Card variant="sticker">
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
            <span style={{ color: 'var(--ginger-600)' }}><IconStar size={18} fill /></span>
            <h4 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 16, margin: 0 }}>Цель недели</h4>
          </div>
          <p style={{ fontSize: 13.5, color: 'var(--text-muted)', margin: '0 0 14px' }}>Посмотри 5 разборов</p>
          <ProgressBar value={3} max={5} label="Прогресс" tone="success" />
        </Card>

        <Card variant="sticker">
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8, marginBottom: 12 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <span style={{ color: 'var(--gold-600)' }}><IconTrophy size={18} /></span>
              <h4 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 16, margin: 0 }}>Таблица</h4>
            </div>
            <Tabs tabs={[{ id: 'week', label: 'Нед.' }, { id: 'all', label: 'Всё' }]} value={tab} onChange={setTab} />
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {BOARD.map((b, i) => (
              <div key={b.n} style={{
                display: 'flex', alignItems: 'center', gap: 10, padding: '8px 10px', borderRadius: 'var(--radius-md)',
                background: b.me ? 'var(--ginger-100)' : 'transparent',
                border: b.me ? '2px solid var(--ginger-300)' : '2px solid transparent',
              }}>
                <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 14, color: i === 0 ? 'var(--gold-700)' : 'var(--text-muted)', width: 18 }}>{i + 1}</span>
                <Avatar name={b.n} size="xs" halo={b.d} />
                <span style={{ flex: 1, fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 14, color: 'var(--text-strong)' }}>{b.n}</span>
                <span style={{ fontFamily: 'var(--font-mono)', fontWeight: 700, fontSize: 13, color: 'var(--text-muted)' }}>{b.xp}</span>
              </div>
            ))}
          </div>
        </Card>

        <Card variant="default" style={{ background: 'var(--ink)', color: 'var(--cream-100)', border: '2.5px solid var(--ink)' }}>
          <Badge tone="live" dot>Скоро</Badge>
          <h4 style={{ fontFamily: 'var(--font-display)', fontWeight: 800, fontSize: 17, margin: '10px 0 4px', color: 'var(--cream-50)' }}>Стрим: ранкеды</h4>
          <p style={{ fontSize: 13.5, color: 'var(--sand-300)', margin: '0 0 14px', display: 'flex', alignItems: 'center', gap: 6 }}>
            <IconClock size={15} /> Сегодня в 19:00
          </p>
          <Button variant="primary" size="sm" fullWidth>Напомнить</Button>
        </Card>
      </div>
    </div>
  );
}
