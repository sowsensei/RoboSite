/* @ds-bundle: {"format":3,"namespace":"SenseiCatDesignSystem_721e9a","components":[{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"ProgressBar","sourcePath":"components/feedback/ProgressBar.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"},{"name":"AppShell","sourcePath":"ui_kits/app/AppShell.jsx"},{"name":"Dashboard","sourcePath":"ui_kits/app/Dashboard.jsx"},{"name":"LoginScreen","sourcePath":"ui_kits/app/LoginScreen.jsx"},{"name":"Sidebar","sourcePath":"ui_kits/app/Sidebar.jsx"},{"name":"TopBar","sourcePath":"ui_kits/app/TopBar.jsx"},{"name":"Hero","sourcePath":"ui_kits/website/Hero.jsx"},{"name":"IconPlay","sourcePath":"ui_kits/website/Icons.jsx"},{"name":"IconBell","sourcePath":"ui_kits/website/Icons.jsx"},{"name":"IconSend","sourcePath":"ui_kits/website/Icons.jsx"},{"name":"IconSearch","sourcePath":"ui_kits/website/Icons.jsx"},{"name":"IconMenu","sourcePath":"ui_kits/website/Icons.jsx"},{"name":"IconHeart","sourcePath":"ui_kits/website/Icons.jsx"},{"name":"IconFire","sourcePath":"ui_kits/website/Icons.jsx"},{"name":"IconHome","sourcePath":"ui_kits/website/Icons.jsx"},{"name":"IconVideo","sourcePath":"ui_kits/website/Icons.jsx"},{"name":"IconTrophy","sourcePath":"ui_kits/website/Icons.jsx"},{"name":"IconUsers","sourcePath":"ui_kits/website/Icons.jsx"},{"name":"IconChevron","sourcePath":"ui_kits/website/Icons.jsx"},{"name":"IconClock","sourcePath":"ui_kits/website/Icons.jsx"},{"name":"IconEye","sourcePath":"ui_kits/website/Icons.jsx"},{"name":"IconStar","sourcePath":"ui_kits/website/Icons.jsx"},{"name":"IconGrid","sourcePath":"ui_kits/website/Icons.jsx"},{"name":"IconSettings","sourcePath":"ui_kits/website/Icons.jsx"},{"name":"SiteFooter","sourcePath":"ui_kits/website/SiteFooter.jsx"},{"name":"SiteHeader","sourcePath":"ui_kits/website/SiteHeader.jsx"},{"name":"SupportCTA","sourcePath":"ui_kits/website/SupportCTA.jsx"},{"name":"VideoGrid","sourcePath":"ui_kits/website/VideoGrid.jsx"}],"sourceHashes":{"components/core/Avatar.jsx":"e71d263d113e","components/core/Badge.jsx":"1477fb8c127e","components/core/Button.jsx":"c4f96198227d","components/core/Card.jsx":"8dde219a2f27","components/core/Tag.jsx":"b0b07cff3f32","components/feedback/ProgressBar.jsx":"b387cd3ee414","components/forms/Checkbox.jsx":"4d3008a671f1","components/forms/Input.jsx":"e8a4055ff146","components/forms/Switch.jsx":"41b165910f21","components/navigation/Tabs.jsx":"9c79d855f04b","ui_kits/app/AppShell.jsx":"52bf75ab7217","ui_kits/app/Dashboard.jsx":"f2ec4310f115","ui_kits/app/LoginScreen.jsx":"55609d8b54bd","ui_kits/app/Sidebar.jsx":"aac1c9c1eed5","ui_kits/app/TopBar.jsx":"acbe05aa5fc4","ui_kits/website/Hero.jsx":"385f68a4dc44","ui_kits/website/Icons.jsx":"d266c5111be8","ui_kits/website/SiteFooter.jsx":"869e0507b5b1","ui_kits/website/SiteHeader.jsx":"e8e858e690df","ui_kits/website/SupportCTA.jsx":"8b126c793055","ui_kits/website/VideoGrid.jsx":"8aa0a2287d5d"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.SenseiCatDesignSystem_721e9a = window.SenseiCatDesignSystem_721e9a || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function useStyleOnce(id, css) {
  if (typeof document === 'undefined') return;
  if (document.getElementById(id)) return;
  const el = document.createElement('style');
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
const CSS = `
.sx-avatar{
  position:relative; display:inline-flex; align-items:center; justify-content:center;
  border-radius:50%; background:var(--lavender-300); color:var(--ink); overflow:hidden;
  border:var(--border-2) solid var(--ink); flex:none;
  font-family:var(--font-display); font-weight:var(--fw-bold);
}
.sx-avatar img{ width:100%; height:100%; object-fit:cover; }
.sx-avatar--xs{ width:28px; height:28px; font-size:11px; border-width:1.5px; }
.sx-avatar--sm{ width:36px; height:36px; font-size:13px; }
.sx-avatar--md{ width:48px; height:48px; font-size:17px; }
.sx-avatar--lg{ width:64px; height:64px; font-size:22px; }
.sx-avatar--xl{ width:88px; height:88px; font-size:30px; }
.sx-avatar--halo::after{
  content:""; position:absolute; inset:-26%; z-index:-1; border-radius:50%;
  background:radial-gradient(circle,var(--lavender-300) 30%, transparent 70%);
}
.sx-avatar__ring{ position:relative; display:inline-flex; }
.sx-avatar__ring::before{
  content:""; position:absolute; inset:-5px; border-radius:50%;
  border:var(--border-2) solid var(--ginger-500);
}
.sx-avatar__online{
  position:absolute; right:-1px; bottom:-1px; width:30%; height:30%;
  background:var(--success-500); border:2px solid var(--bg-surface); border-radius:50%;
}
`;
function Avatar({
  src = null,
  name = '',
  size = 'md',
  halo = false,
  online = false,
  className = '',
  ...rest
}) {
  useStyleOnce('sx-avatar-css', CSS);
  const initials = name ? name.trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase() : '?';
  const cls = ['sx-avatar', `sx-avatar--${size}`, halo && 'sx-avatar--halo', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls
  }, rest), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name
  }) : initials, online && /*#__PURE__*/React.createElement("span", {
    className: "sx-avatar__online"
  }));
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function useStyleOnce(id, css) {
  if (typeof document === 'undefined') return;
  if (document.getElementById(id)) return;
  const el = document.createElement('style');
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
const CSS = `
.sx-badge{
  font-family:var(--font-display); font-weight:var(--fw-bold); font-size:12px; line-height:1;
  letter-spacing:.02em; display:inline-flex; align-items:center; gap:5px;
  padding:5px 10px; border-radius:var(--radius-pill); white-space:nowrap;
  border:var(--border-1) solid transparent;
}
.sx-badge .sx-dot{ width:7px; height:7px; border-radius:50%; background:currentColor; }
.sx-badge--solid{ color:var(--text-on-brand); background:var(--ginger-500); border-color:var(--ink); }
.sx-badge--ginger{ color:var(--ginger-800); background:var(--ginger-100); border-color:var(--ginger-300); }
.sx-badge--grape{ color:var(--grape-700); background:var(--lavender-100); border-color:var(--lavender-300); }
.sx-badge--cyan{ color:var(--cyan-700); background:var(--cyan-100); border-color:var(--cyan-300); }
.sx-badge--success{ color:var(--success-700); background:var(--success-100); border-color:#bfe6cf; }
.sx-badge--danger{ color:var(--danger-700); background:var(--danger-100); border-color:#f3cac6; }
.sx-badge--warning{ color:var(--warning-700); background:var(--warning-100); border-color:#f0dca0; }
.sx-badge--neutral{ color:var(--brown-700); background:var(--cream-200); border-color:var(--sand-300); }
.sx-badge--live{ color:#fff; background:var(--danger-500); border-color:var(--ink); }
.sx-badge--live .sx-dot{ animation:sx-pulse 1.4s infinite; }
@keyframes sx-pulse{ 0%,100%{opacity:1} 50%{opacity:.35} }
`;
function Badge({
  children,
  tone = 'ginger',
  dot = false,
  className = '',
  ...rest
}) {
  useStyleOnce('sx-badge-css', CSS);
  const cls = ['sx-badge', `sx-badge--${tone}`, className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    className: "sx-dot"
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Injects a component's CSS once per document. */
function useStyleOnce(id, css) {
  if (typeof document === 'undefined') return;
  if (document.getElementById(id)) return;
  const el = document.createElement('style');
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
const CSS = `
.sx-btn{
  --_bg:var(--ginger-500); --_fg:var(--text-on-brand); --_bd:var(--ink); --_sh:var(--ink);
  font-family:var(--font-display); font-weight:var(--fw-bold); line-height:1;
  display:inline-flex; align-items:center; justify-content:center; gap:.5em;
  border:var(--border-2) solid var(--_bd); border-radius:var(--radius-pill);
  background:var(--_bg); color:var(--_fg); cursor:pointer; white-space:nowrap;
  box-shadow:2px 2px 0 var(--_sh); transition:transform .08s ease, box-shadow .08s ease, background .15s ease;
  -webkit-tap-highlight-color:transparent;
}
.sx-btn:hover{ transform:translate(-1px,-1px); box-shadow:3px 3px 0 var(--_sh); }
.sx-btn:active{ transform:translate(2px,2px); box-shadow:0 0 0 var(--_sh); }
.sx-btn:focus-visible{ outline:none; box-shadow:2px 2px 0 var(--_sh), var(--ring); }
.sx-btn[disabled]{ opacity:.5; cursor:not-allowed; transform:none; box-shadow:2px 2px 0 var(--_sh); }
.sx-btn--sm{ font-size:13px; padding:8px 14px; }
.sx-btn--md{ font-size:15px; padding:11px 20px; }
.sx-btn--lg{ font-size:18px; padding:15px 28px; }
.sx-btn--full{ width:100%; }
/* variants */
.sx-btn--primary{ --_bg:var(--ginger-500); --_fg:var(--text-on-brand); }
.sx-btn--primary:hover{ --_bg:var(--ginger-400); }
.sx-btn--secondary{ --_bg:var(--bg-surface); --_fg:var(--text-strong); }
.sx-btn--secondary:hover{ --_bg:var(--cream-100); }
.sx-btn--accent{ --_bg:var(--grape-500); --_fg:#fff; }
.sx-btn--accent:hover{ --_bg:var(--grape-400); }
.sx-btn--cool{ --_bg:var(--cyan-500); --_fg:#fff; }
.sx-btn--cool:hover{ --_bg:var(--cyan-400); }
.sx-btn--danger{ --_bg:var(--danger-500); --_fg:#fff; }
.sx-btn--ghost{ --_bg:transparent; --_fg:var(--text-strong); border-color:transparent; box-shadow:none; }
.sx-btn--ghost:hover{ --_bg:var(--cream-100); transform:none; box-shadow:none; }
.sx-btn--ghost:active{ transform:translate(1px,1px); box-shadow:none; }
.sx-btn--ghost:focus-visible{ box-shadow:var(--ring); }
`;
function Button({
  children,
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  iconLeft = null,
  iconRight = null,
  type = 'button',
  className = '',
  ...rest
}) {
  useStyleOnce('sx-btn-css', CSS);
  const cls = ['sx-btn', `sx-btn--${variant}`, `sx-btn--${size}`, fullWidth ? 'sx-btn--full' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    className: cls
  }, rest), iconLeft, children != null && /*#__PURE__*/React.createElement("span", null, children), iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function useStyleOnce(id, css) {
  if (typeof document === 'undefined') return;
  if (document.getElementById(id)) return;
  const el = document.createElement('style');
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
const CSS = `
.sx-card{
  background:var(--bg-surface); border-radius:var(--radius-xl); overflow:hidden;
  border:var(--border-1) solid var(--border-soft); box-shadow:var(--shadow-md);
  display:flex; flex-direction:column; transition:transform .12s ease, box-shadow .12s ease;
}
/* sticker = the comic look: ink outline + hard pop shadow */
.sx-card--sticker{ border:var(--border-2) solid var(--ink); box-shadow:var(--pop); }
.sx-card--flat{ box-shadow:none; }
.sx-card--interactive{ cursor:pointer; }
.sx-card--interactive:hover{ transform:translateY(-3px); box-shadow:var(--shadow-lg); }
.sx-card--sticker.sx-card--interactive:hover{ transform:translate(-2px,-2px); box-shadow:var(--pop-lg); }
.sx-card__media{ position:relative; aspect-ratio:16/9; background:var(--cream-200); overflow:hidden; }
.sx-card__media img{ width:100%; height:100%; object-fit:cover; display:block; }
.sx-card__body{ padding:var(--space-5); display:flex; flex-direction:column; gap:var(--space-2); }
`;
function Card({
  children,
  variant = 'default',
  // 'default' | 'sticker' | 'flat'
  interactive = false,
  media = null,
  className = '',
  ...rest
}) {
  useStyleOnce('sx-card-css', CSS);
  const cls = ['sx-card', variant !== 'default' ? `sx-card--${variant}` : '', interactive ? 'sx-card--interactive' : '', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cls
  }, rest), media && /*#__PURE__*/React.createElement("div", {
    className: "sx-card__media"
  }, media), /*#__PURE__*/React.createElement("div", {
    className: "sx-card__body"
  }, children));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function useStyleOnce(id, css) {
  if (typeof document === 'undefined') return;
  if (document.getElementById(id)) return;
  const el = document.createElement('style');
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
const CSS = `
.sx-tag{
  font-family:var(--font-body); font-weight:var(--fw-bold); font-size:13px; line-height:1;
  display:inline-flex; align-items:center; gap:6px; cursor:default;
  padding:7px 12px; border-radius:var(--radius-pill);
  background:var(--cream-100); color:var(--brown-700);
  border:var(--border-1) solid var(--sand-300); transition:background .15s, border-color .15s, color .15s;
}
.sx-tag--clickable{ cursor:pointer; }
.sx-tag--clickable:hover{ background:var(--ginger-100); border-color:var(--ginger-300); color:var(--ginger-800); }
.sx-tag--active{ background:var(--ginger-500); border-color:var(--ink); color:var(--text-on-brand); }
.sx-tag__x{ display:inline-flex; width:14px; height:14px; align-items:center; justify-content:center;
  border-radius:50%; font-size:11px; line-height:1; opacity:.6; }
.sx-tag__x:hover{ opacity:1; }
`;
function Tag({
  children,
  active = false,
  onClick,
  onRemove,
  className = '',
  ...rest
}) {
  useStyleOnce('sx-tag-css', CSS);
  const clickable = !!onClick;
  const cls = ['sx-tag', clickable && 'sx-tag--clickable', active && 'sx-tag--active', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls,
    onClick: onClick
  }, rest), children, onRemove && /*#__PURE__*/React.createElement("span", {
    className: "sx-tag__x",
    onClick: e => {
      e.stopPropagation();
      onRemove(e);
    }
  }, "\u2715"));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/feedback/ProgressBar.jsx
try { (() => {
function useStyleOnce(id, css) {
  if (typeof document === 'undefined') return;
  if (document.getElementById(id)) return;
  const el = document.createElement('style');
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
const CSS = `
.sx-prog{ display:flex; flex-direction:column; gap:6px; font-family:var(--font-body); }
.sx-prog__top{ display:flex; justify-content:space-between; align-items:baseline; }
.sx-prog__label{ font-family:var(--font-display); font-weight:var(--fw-semibold); font-size:13px; color:var(--text-strong); }
.sx-prog__val{ font-family:var(--font-mono); font-weight:700; font-size:13px; color:var(--text-muted); }
.sx-prog__track{ height:14px; border-radius:var(--radius-pill); background:var(--cream-200);
  border:var(--border-2) solid var(--ink); overflow:hidden; }
.sx-prog__fill{ height:100%; border-radius:var(--radius-pill);
  background:var(--ginger-500); transition:width .4s cubic-bezier(.34,1.4,.64,1); }
.sx-prog__fill--cyan{ background:var(--cyan-500); }
.sx-prog__fill--grape{ background:var(--grape-500); }
.sx-prog__fill--gold{ background:var(--gold-500); }
.sx-prog__fill--success{ background:var(--success-500); }
`;
function ProgressBar({
  value = 0,
  max = 100,
  label,
  showValue = true,
  tone = 'ginger',
  className = ''
}) {
  useStyleOnce('sx-prog-css', CSS);
  const pct = Math.max(0, Math.min(100, value / max * 100));
  return /*#__PURE__*/React.createElement("div", {
    className: ['sx-prog', className].filter(Boolean).join(' ')
  }, (label || showValue) && /*#__PURE__*/React.createElement("div", {
    className: "sx-prog__top"
  }, label && /*#__PURE__*/React.createElement("span", {
    className: "sx-prog__label"
  }, label), showValue && /*#__PURE__*/React.createElement("span", {
    className: "sx-prog__val"
  }, Math.round(pct), "%")), /*#__PURE__*/React.createElement("div", {
    className: "sx-prog__track"
  }, /*#__PURE__*/React.createElement("div", {
    className: `sx-prog__fill sx-prog__fill--${tone}`,
    style: {
      width: pct + '%'
    }
  })));
}
Object.assign(__ds_scope, { ProgressBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/ProgressBar.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function useStyleOnce(id, css) {
  if (typeof document === 'undefined') return;
  if (document.getElementById(id)) return;
  const el = document.createElement('style');
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
const CSS = `
.sx-check{ display:inline-flex; align-items:flex-start; gap:10px; cursor:pointer; font-family:var(--font-body);
  font-weight:500; font-size:15px; color:var(--text-body); user-select:none; }
.sx-check input{ position:absolute; opacity:0; width:0; height:0; }
.sx-check__box{
  width:24px; height:24px; flex:none; border-radius:var(--radius-sm);
  background:var(--bg-surface); border:var(--border-2) solid var(--ink);
  display:inline-flex; align-items:center; justify-content:center;
  box-shadow:var(--pop-sm); transition:background .14s, box-shadow .08s, transform .08s;
}
.sx-check__box svg{ width:15px; height:15px; opacity:0; transform:scale(.5); transition:opacity .12s, transform .12s; }
.sx-check input:checked + .sx-check__box{ background:var(--ginger-500); }
.sx-check input:checked + .sx-check__box svg{ opacity:1; transform:scale(1); }
.sx-check:active .sx-check__box{ transform:translate(1px,1px); box-shadow:0 0 0; }
.sx-check input:focus-visible + .sx-check__box{ box-shadow:var(--pop-sm), var(--ring); }
.sx-check--disabled{ opacity:.5; cursor:not-allowed; }
`;
function Checkbox({
  checked,
  onChange,
  label,
  disabled = false,
  className = '',
  ...rest
}) {
  useStyleOnce('sx-check-css', CSS);
  const cls = ['sx-check', disabled && 'sx-check--disabled', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("label", {
    className: cls
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    checked: checked,
    onChange: onChange,
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "sx-check__box"
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--ink)",
    strokeWidth: "3.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M5 12.5l4.5 4.5L19 6"
  }))), label && /*#__PURE__*/React.createElement("span", null, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function useStyleOnce(id, css) {
  if (typeof document === 'undefined') return;
  if (document.getElementById(id)) return;
  const el = document.createElement('style');
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
const CSS = `
.sx-field{ display:flex; flex-direction:column; gap:6px; font-family:var(--font-body); }
.sx-field__label{ font-family:var(--font-display); font-weight:var(--fw-semibold); font-size:14px; color:var(--text-strong); }
.sx-field__hint{ font-size:12.5px; color:var(--text-muted); }
.sx-field__hint--error{ color:var(--danger-700); font-weight:600; }
.sx-input-wrap{ position:relative; display:flex; align-items:center; }
.sx-input-wrap__icon{ position:absolute; left:14px; display:inline-flex; color:var(--text-muted); pointer-events:none; }
.sx-input{
  width:100%; box-sizing:border-box; font-family:var(--font-body); font-weight:500; font-size:15px;
  color:var(--text-strong); background:var(--bg-surface);
  border:var(--border-2) solid var(--sand-400); border-radius:var(--radius-md);
  padding:11px 14px; transition:border-color .15s, box-shadow .15s;
}
.sx-input::placeholder{ color:var(--text-faint); }
.sx-input--has-icon{ padding-left:40px; }
.sx-input:hover{ border-color:var(--brown-300); }
.sx-input:focus{ outline:none; border-color:var(--ginger-500); box-shadow:var(--ring); }
.sx-input--error{ border-color:var(--danger-500); }
.sx-input--error:focus{ box-shadow:0 0 0 4px rgba(216,53,42,.25); }
.sx-input:disabled{ background:var(--cream-100); color:var(--text-muted); cursor:not-allowed; }
`;
function Input({
  label,
  hint,
  error,
  icon = null,
  id,
  className = '',
  ...rest
}) {
  useStyleOnce('sx-input-css', CSS);
  const fid = id || (label ? 'sx-' + label.replace(/\s+/g, '-').toLowerCase() : undefined);
  const inputCls = ['sx-input', icon && 'sx-input--has-icon', error && 'sx-input--error', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("div", {
    className: "sx-field"
  }, label && /*#__PURE__*/React.createElement("label", {
    className: "sx-field__label",
    htmlFor: fid
  }, label), /*#__PURE__*/React.createElement("div", {
    className: "sx-input-wrap"
  }, icon && /*#__PURE__*/React.createElement("span", {
    className: "sx-input-wrap__icon"
  }, icon), /*#__PURE__*/React.createElement("input", _extends({
    id: fid,
    className: inputCls
  }, rest))), error ? /*#__PURE__*/React.createElement("span", {
    className: "sx-field__hint sx-field__hint--error"
  }, error) : hint && /*#__PURE__*/React.createElement("span", {
    className: "sx-field__hint"
  }, hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function useStyleOnce(id, css) {
  if (typeof document === 'undefined') return;
  if (document.getElementById(id)) return;
  const el = document.createElement('style');
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
const CSS = `
.sx-switch{ display:inline-flex; align-items:center; gap:10px; cursor:pointer; font-family:var(--font-body);
  font-weight:600; font-size:14px; color:var(--text-strong); user-select:none; }
.sx-switch input{ position:absolute; opacity:0; width:0; height:0; }
.sx-switch__track{
  position:relative; width:46px; height:27px; border-radius:var(--radius-pill);
  background:var(--sand-400); border:var(--border-2) solid var(--ink);
  transition:background .18s ease; flex:none;
}
.sx-switch__thumb{
  position:absolute; top:1.5px; left:1.5px; width:20px; height:20px; border-radius:50%;
  background:var(--cream-50); border:var(--border-2) solid var(--ink);
  transition:transform .18s cubic-bezier(.34,1.56,.64,1);
}
.sx-switch input:checked + .sx-switch__track{ background:var(--ginger-500); }
.sx-switch input:checked + .sx-switch__track .sx-switch__thumb{ transform:translateX(19px); }
.sx-switch input:focus-visible + .sx-switch__track{ box-shadow:var(--ring); }
.sx-switch--disabled{ opacity:.5; cursor:not-allowed; }
`;
function Switch({
  checked,
  onChange,
  label,
  disabled = false,
  className = '',
  ...rest
}) {
  useStyleOnce('sx-switch-css', CSS);
  const cls = ['sx-switch', disabled && 'sx-switch--disabled', className].filter(Boolean).join(' ');
  return /*#__PURE__*/React.createElement("label", {
    className: cls
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    checked: checked,
    onChange: onChange,
    disabled: disabled
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "sx-switch__track"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sx-switch__thumb"
  })), label && /*#__PURE__*/React.createElement("span", null, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function useStyleOnce(id, css) {
  if (typeof document === 'undefined') return;
  if (document.getElementById(id)) return;
  const el = document.createElement('style');
  el.id = id;
  el.textContent = css;
  document.head.appendChild(el);
}
const CSS = `
.sx-tabs{ display:inline-flex; gap:4px; padding:5px; background:var(--cream-100);
  border:var(--border-2) solid var(--ink); border-radius:var(--radius-pill); }
.sx-tab{
  font-family:var(--font-display); font-weight:var(--fw-bold); font-size:14px; line-height:1;
  padding:9px 18px; border-radius:var(--radius-pill); border:none; background:transparent;
  color:var(--brown-700); cursor:pointer; white-space:nowrap; transition:background .15s, color .15s;
}
.sx-tab:hover{ color:var(--ginger-700); }
.sx-tab--active{ background:var(--ginger-500); color:var(--text-on-brand);
  box-shadow:1.5px 1.5px 0 var(--ink); }
.sx-tab:focus-visible{ outline:none; box-shadow:var(--ring); }
`;
function Tabs({
  tabs = [],
  value,
  onChange,
  className = ''
}) {
  useStyleOnce('sx-tabs-css', CSS);
  return /*#__PURE__*/React.createElement("div", {
    className: ['sx-tabs', className].filter(Boolean).join(' '),
    role: "tablist"
  }, tabs.map(t => {
    const id = typeof t === 'string' ? t : t.id;
    const label = typeof t === 'string' ? t : t.label;
    const active = id === value;
    return /*#__PURE__*/React.createElement("button", {
      key: id,
      role: "tab",
      "aria-selected": active,
      className: ['sx-tab', active && 'sx-tab--active'].filter(Boolean).join(' '),
      onClick: () => onChange && onChange(id)
    }, label);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Icons.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* Lucide-style line icons (2px stroke, round caps) used across the kits.
   Pass `size` (px). Color follows `currentColor`. */
function svg(paths, vb = '0 0 24 24') {
  return function Icon({
    size = 20,
    fill = false,
    ...rest
  }) {
    return /*#__PURE__*/React.createElement("svg", _extends({
      width: size,
      height: size,
      viewBox: vb,
      fill: fill ? 'currentColor' : 'none',
      stroke: "currentColor",
      strokeWidth: "2",
      strokeLinecap: "round",
      strokeLinejoin: "round"
    }, rest), paths);
  };
}
const IconPlay = svg(/*#__PURE__*/React.createElement("path", {
  d: "M6 4l14 8-14 8V4z",
  fill: "currentColor",
  stroke: "none"
}));
const IconBell = svg(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
  d: "M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"
}), /*#__PURE__*/React.createElement("path", {
  d: "M13.7 21a2 2 0 0 1-3.4 0"
})));
const IconSend = svg(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
  d: "M22 2 11 13"
}), /*#__PURE__*/React.createElement("path", {
  d: "M22 2 15 22l-4-9-9-4 20-7z"
})));
const IconSearch = svg(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
  cx: "11",
  cy: "11",
  r: "8"
}), /*#__PURE__*/React.createElement("path", {
  d: "m21 21-4.3-4.3"
})));
const IconMenu = svg(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
  d: "M4 6h16"
}), /*#__PURE__*/React.createElement("path", {
  d: "M4 12h16"
}), /*#__PURE__*/React.createElement("path", {
  d: "M4 18h16"
})));
const IconHeart = svg(/*#__PURE__*/React.createElement("path", {
  d: "M19 14c1.5-1.5 3-3.4 3-5.5A4.5 4.5 0 0 0 12 6 4.5 4.5 0 0 0 2 8.5c0 2.1 1.5 4 3 5.5l7 7 7-7z"
}));
const IconFire = svg(/*#__PURE__*/React.createElement("path", {
  d: "M12 2c1 3 4 4.5 4 8a4 4 0 0 1-8 0c0-1 .3-2 1-3-2 1-4 3-4 6a7 7 0 0 0 14 0c0-5-4-7-7-11z"
}));
const IconHome = svg(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
  d: "M3 10.5 12 3l9 7.5"
}), /*#__PURE__*/React.createElement("path", {
  d: "M5 9.5V21h14V9.5"
})));
const IconVideo = svg(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
  x: "2",
  y: "5",
  width: "15",
  height: "14",
  rx: "3"
}), /*#__PURE__*/React.createElement("path", {
  d: "m17 9 5-3v12l-5-3"
})));
const IconTrophy = svg(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
  d: "M8 21h8"
}), /*#__PURE__*/React.createElement("path", {
  d: "M12 17v4"
}), /*#__PURE__*/React.createElement("path", {
  d: "M7 4h10v5a5 5 0 0 1-10 0V4z"
}), /*#__PURE__*/React.createElement("path", {
  d: "M7 6H4v2a3 3 0 0 0 3 3"
}), /*#__PURE__*/React.createElement("path", {
  d: "M17 6h3v2a3 3 0 0 1-3 3"
})));
const IconUsers = svg(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
  cx: "9",
  cy: "8",
  r: "3.5"
}), /*#__PURE__*/React.createElement("path", {
  d: "M2.5 20a6.5 6.5 0 0 1 13 0"
}), /*#__PURE__*/React.createElement("path", {
  d: "M16 5a3.5 3.5 0 0 1 0 6.5"
}), /*#__PURE__*/React.createElement("path", {
  d: "M17.5 20a6.5 6.5 0 0 0-2-4.7"
})));
const IconChevron = svg(/*#__PURE__*/React.createElement("path", {
  d: "m9 6 6 6-6 6"
}));
const IconClock = svg(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "12",
  r: "9"
}), /*#__PURE__*/React.createElement("path", {
  d: "M12 7v5l3 2"
})));
const IconEye = svg(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
  d: "M2 12s4-7 10-7 10 7 10 7-4 7-10 7-10-7-10-7z"
}), /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "12",
  r: "3"
})));
const IconStar = svg(/*#__PURE__*/React.createElement("path", {
  d: "m12 3 2.7 5.5 6 .9-4.3 4.2 1 6L12 17l-5.4 2.8 1-6L3.3 9.4l6-.9L12 3z"
}));
const IconGrid = svg(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
  x: "3",
  y: "3",
  width: "7",
  height: "7",
  rx: "1.5"
}), /*#__PURE__*/React.createElement("rect", {
  x: "14",
  y: "3",
  width: "7",
  height: "7",
  rx: "1.5"
}), /*#__PURE__*/React.createElement("rect", {
  x: "3",
  y: "14",
  width: "7",
  height: "7",
  rx: "1.5"
}), /*#__PURE__*/React.createElement("rect", {
  x: "14",
  y: "14",
  width: "7",
  height: "7",
  rx: "1.5"
})));
const IconSettings = svg(/*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
  cx: "12",
  cy: "12",
  r: "3"
}), /*#__PURE__*/React.createElement("path", {
  d: "M12 2v3M12 19v3M4.2 4.2l2.1 2.1M17.7 17.7l2.1 2.1M2 12h3M19 12h3M4.2 19.8l2.1-2.1M17.7 6.3l2.1-2.1"
})));
Object.assign(__ds_scope, { IconPlay, IconBell, IconSend, IconSearch, IconMenu, IconHeart, IconFire, IconHome, IconVideo, IconTrophy, IconUsers, IconChevron, IconClock, IconEye, IconStar, IconGrid, IconSettings });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Icons.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/Dashboard.jsx
try { (() => {
const CONTINUE = [{
  t: 'Тайминги Roshan',
  sub: 'Гайд · 12 мин',
  p: 64,
  bg: 'var(--cyan-200)'
}, {
  t: 'Сборка на Invoker',
  sub: 'Разбор · 24 мин',
  p: 30,
  bg: 'var(--ginger-200)'
}, {
  t: 'Вард-контроль',
  sub: 'Урок · 9 мин',
  p: 88,
  bg: 'var(--lavender-200)'
}];
const BOARD = [{
  n: 'KittyMid',
  xp: '14 920',
  d: true
}, {
  n: 'rawr_pro',
  xp: '12 340'
}, {
  n: 'Иван Котов',
  xp: '9 880',
  me: true
}, {
  n: 'sunsetcat',
  xp: '8 410'
}];
function Dashboard() {
  const [tab, setTab] = React.useState('week');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 28,
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1fr) 320px',
      gap: 24,
      alignItems: 'start'
    },
    className: "sx-dash"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 24,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      overflow: 'hidden',
      display: 'grid',
      gridTemplateColumns: '1fr auto',
      gap: 16,
      alignItems: 'center',
      padding: '26px 28px',
      background: 'linear-gradient(120deg, var(--ginger-100), var(--lavender-100))',
      border: '3px solid var(--ink)',
      borderRadius: 'var(--radius-2xl)',
      boxShadow: 'var(--pop)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "sensei-eyebrow"
  }, "\u0421 \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0435\u043D\u0438\u0435\u043C"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 30,
      margin: '8px 0 6px'
    }
  }, "\u041F\u0440\u0438\u0432\u0435\u0442, \u0418\u0432\u0430\u043D! \uD83D\uDC3E"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 16,
      color: 'var(--brown-700)',
      margin: '0 0 18px',
      maxWidth: '44ch'
    }
  }, "\u0421\u0435\u043D\u0441\u0435\u0439 \u043F\u043E\u0434\u0433\u043E\u0442\u043E\u0432\u0438\u043B 3 \u043D\u043E\u0432\u044B\u0445 \u0440\u0430\u0437\u0431\u043E\u0440\u0430. \u041F\u0440\u043E\u0434\u043E\u043B\u0436\u0430\u0439 \u0441\u0435\u0440\u0438\u044E \u2014 \u0442\u044B \u0432 \u0443\u0434\u0430\u0440\u0435 5 \u0434\u043D\u0435\u0439 \u043F\u043E\u0434\u0440\u044F\u0434."), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    iconLeft: /*#__PURE__*/React.createElement(__ds_scope.IconPlay, {
      size: 16
    })
  }, "\u041F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435")), /*#__PURE__*/React.createElement("img", {
    src: "../../assets/mascots/sensei-phone.png",
    alt: "",
    style: {
      width: 150,
      objectFit: 'contain',
      filter: 'drop-shadow(0 12px 18px rgba(46,26,14,0.22))'
    },
    className: "sx-hide-sm"
  })), /*#__PURE__*/React.createElement("section", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 20,
      margin: '0 0 14px'
    }
  }, "\u041F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C \u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(190px,1fr))',
      gap: 16
    }
  }, CONTINUE.map((c, i) => /*#__PURE__*/React.createElement(__ds_scope.Card, {
    key: i,
    variant: "sticker",
    interactive: true,
    media: /*#__PURE__*/React.createElement("div", {
      style: {
        position: 'relative',
        height: '100%',
        background: c.bg,
        display: 'grid',
        placeItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 46,
        height: 46,
        display: 'grid',
        placeItems: 'center',
        background: 'var(--bg-surface)',
        color: 'var(--ginger-600)',
        border: '2.5px solid var(--ink)',
        borderRadius: '50%',
        boxShadow: 'var(--pop-sm)'
      }
    }, /*#__PURE__*/React.createElement(__ds_scope.IconPlay, {
      size: 18
    })))
  }, /*#__PURE__*/React.createElement("h4", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 15,
      margin: '0 0 8px',
      color: 'var(--text-strong)'
    }
  }, c.t), /*#__PURE__*/React.createElement(__ds_scope.ProgressBar, {
    value: c.p,
    max: 100,
    showValue: false,
    tone: i === 1 ? 'cyan' : 'ginger'
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12.5,
      color: 'var(--text-muted)',
      fontWeight: 600,
      marginTop: 6
    }
  }, c.sub)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    },
    className: "sx-rail"
  }, /*#__PURE__*/React.createElement(__ds_scope.Card, {
    variant: "sticker"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--ginger-600)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.IconStar, {
    size: 18,
    fill: true
  })), /*#__PURE__*/React.createElement("h4", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 16,
      margin: 0
    }
  }, "\u0426\u0435\u043B\u044C \u043D\u0435\u0434\u0435\u043B\u0438")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13.5,
      color: 'var(--text-muted)',
      margin: '0 0 14px'
    }
  }, "\u041F\u043E\u0441\u043C\u043E\u0442\u0440\u0438 5 \u0440\u0430\u0437\u0431\u043E\u0440\u043E\u0432"), /*#__PURE__*/React.createElement(__ds_scope.ProgressBar, {
    value: 3,
    max: 5,
    label: "\u041F\u0440\u043E\u0433\u0440\u0435\u0441\u0441",
    tone: "success"
  })), /*#__PURE__*/React.createElement(__ds_scope.Card, {
    variant: "sticker"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 8,
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--gold-600)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.IconTrophy, {
    size: 18
  })), /*#__PURE__*/React.createElement("h4", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 16,
      margin: 0
    }
  }, "\u0422\u0430\u0431\u043B\u0438\u0446\u0430")), /*#__PURE__*/React.createElement(__ds_scope.Tabs, {
    tabs: [{
      id: 'week',
      label: 'Нед.'
    }, {
      id: 'all',
      label: 'Всё'
    }],
    value: tab,
    onChange: setTab
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, BOARD.map((b, i) => /*#__PURE__*/React.createElement("div", {
    key: b.n,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '8px 10px',
      borderRadius: 'var(--radius-md)',
      background: b.me ? 'var(--ginger-100)' : 'transparent',
      border: b.me ? '2px solid var(--ginger-300)' : '2px solid transparent'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontWeight: 700,
      fontSize: 14,
      color: i === 0 ? 'var(--gold-700)' : 'var(--text-muted)',
      width: 18
    }
  }, i + 1), /*#__PURE__*/React.createElement(__ds_scope.Avatar, {
    name: b.n,
    size: "xs",
    halo: b.d
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 14,
      color: 'var(--text-strong)'
    }
  }, b.n), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontWeight: 700,
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, b.xp))))), /*#__PURE__*/React.createElement(__ds_scope.Card, {
    variant: "default",
    style: {
      background: 'var(--ink)',
      color: 'var(--cream-100)',
      border: '2.5px solid var(--ink)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: "live",
    dot: true
  }, "\u0421\u043A\u043E\u0440\u043E"), /*#__PURE__*/React.createElement("h4", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 17,
      margin: '10px 0 4px',
      color: 'var(--cream-50)'
    }
  }, "\u0421\u0442\u0440\u0438\u043C: \u0440\u0430\u043D\u043A\u0435\u0434\u044B"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 13.5,
      color: 'var(--sand-300)',
      margin: '0 0 14px',
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.IconClock, {
    size: 15
  }), " \u0421\u0435\u0433\u043E\u0434\u043D\u044F \u0432 19:00"), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "primary",
    size: "sm",
    fullWidth: true
  }, "\u041D\u0430\u043F\u043E\u043C\u043D\u0438\u0442\u044C"))));
}
Object.assign(__ds_scope, { Dashboard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/Dashboard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/LoginScreen.jsx
try { (() => {
function LoginScreen({
  onLogin
}) {
  const [remember, setRemember] = React.useState(true);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100vh',
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      background: 'var(--bg-page)'
    },
    className: "sx-auth"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      overflow: 'hidden',
      display: 'grid',
      placeItems: 'center',
      padding: 40,
      background: 'radial-gradient(700px 500px at 50% 30%, var(--lavender-300), var(--grape-600))',
      borderRight: '3px solid var(--ink)'
    },
    className: "sx-auth-brand"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      maxWidth: 380
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/mascots/sensei-master.png",
    alt: "\u0421\u0435\u043D\u0441\u0435\u0439",
    style: {
      width: 220,
      objectFit: 'contain',
      filter: 'drop-shadow(0 16px 24px rgba(46,26,14,0.32))'
    }
  }), /*#__PURE__*/React.createElement("h2", {
    style: {
      color: 'var(--cream-50)',
      fontSize: 30,
      margin: '18px 0 10px'
    }
  }, "\u0414\u043E\u0431\u0440\u043E \u043F\u043E\u0436\u0430\u043B\u043E\u0432\u0430\u0442\u044C \u0432 \u0434\u043E\u0434\u0437\u0451"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--lavender-100)',
      fontSize: 16,
      margin: 0
    }
  }, "\u0423\u0447\u0438\u0441\u044C \u0443 \u0421\u0435\u043D\u0441\u0435\u044F, \u043F\u043E\u0434\u043D\u0438\u043C\u0430\u0439 \u0440\u0430\u043D\u0433 \u0438 \u0442\u0430\u0449\u0438 \u043A\u0430\u0442\u043A\u0438. \u0422\u0451\u043F\u043B\u043E\u0435 \u043A\u043E\u043C\u044C\u044E\u043D\u0438\u0442\u0438 \u0443\u0436\u0435 \u0436\u0434\u0451\u0442."))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      placeItems: 'center',
      padding: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      maxWidth: 380
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "sensei-eyebrow"
  }, "\u0420\u044B\u0436\u0438\u0439 \u043A\u043E\u0442 \xB7 \u0434\u0438\u0437\u0430\u0439\u043D"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 38,
      margin: '10px 0 6px'
    }
  }, "\u0421 \u0432\u043E\u0437\u0432\u0440\u0430\u0449\u0435\u043D\u0438\u0435\u043C!"), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--text-muted)',
      margin: '0 0 26px',
      fontSize: 15.5
    }
  }, "\u0412\u043E\u0439\u0434\u0438, \u0447\u0442\u043E\u0431\u044B \u043F\u0440\u043E\u0434\u043E\u043B\u0436\u0438\u0442\u044C \u043E\u0431\u0443\u0447\u0435\u043D\u0438\u0435."), /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      onLogin && onLogin();
    },
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Input, {
    label: "\u041F\u043E\u0447\u0442\u0430",
    type: "email",
    placeholder: "you@mail.ru",
    defaultValue: "ivan@kot.ru"
  }), /*#__PURE__*/React.createElement(__ds_scope.Input, {
    label: "\u041F\u0430\u0440\u043E\u043B\u044C",
    type: "password",
    placeholder: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022",
    defaultValue: "murmur"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Checkbox, {
    checked: remember,
    onChange: e => setRemember(e.target.checked),
    label: "\u0417\u0430\u043F\u043E\u043C\u043D\u0438\u0442\u044C \u043C\u0435\u043D\u044F"
  }), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      fontSize: 14,
      fontWeight: 700,
      color: 'var(--text-link)'
    }
  }, "\u0417\u0430\u0431\u044B\u043B\u0438?")), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    type: "submit",
    size: "lg",
    fullWidth: true
  }, "\u0412\u043E\u0439\u0442\u0438 \u0432 \u0434\u043E\u0434\u0437\u0451"), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    type: "button",
    variant: "secondary",
    size: "lg",
    fullWidth: true,
    iconLeft: /*#__PURE__*/React.createElement(__ds_scope.IconSend, {
      size: 18
    }),
    onClick: onLogin
  }, "\u0412\u043E\u0439\u0442\u0438 \u0447\u0435\u0440\u0435\u0437 Telegram")), /*#__PURE__*/React.createElement("p", {
    style: {
      textAlign: 'center',
      marginTop: 22,
      fontSize: 14.5,
      color: 'var(--text-muted)'
    }
  }, "\u041D\u0435\u0442 \u0430\u043A\u043A\u0430\u0443\u043D\u0442\u0430? ", /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      fontWeight: 800,
      color: 'var(--ginger-700)'
    }
  }, "\u0421\u043E\u0437\u0434\u0430\u0442\u044C")))));
}
Object.assign(__ds_scope, { LoginScreen });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/LoginScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/Sidebar.jsx
try { (() => {
const NAV = [{
  id: 'home',
  label: 'Главная',
  icon: __ds_scope.IconHome
}, {
  id: 'feed',
  label: 'Лента',
  icon: __ds_scope.IconFire
}, {
  id: 'streams',
  label: 'Стримы',
  icon: __ds_scope.IconVideo,
  badge: 'LIVE'
}, {
  id: 'tournaments',
  label: 'Турниры',
  icon: __ds_scope.IconTrophy
}, {
  id: 'community',
  label: 'Додзё',
  icon: __ds_scope.IconUsers
}];
function Sidebar({
  active = 'home',
  onNavigate
}) {
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 248,
      flex: 'none',
      background: 'var(--bg-surface)',
      borderRight: '2.5px solid var(--ink)',
      display: 'flex',
      flexDirection: 'column',
      padding: '20px 16px',
      gap: 6,
      minHeight: '100%'
    },
    className: "sx-sidebar"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '0 6px 14px'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/mascots/sensei-master.png",
    alt: "",
    style: {
      width: 40,
      height: 40,
      objectFit: 'contain'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 900,
      fontSize: 21,
      color: 'var(--text-strong)'
    }
  }, "\u0421\u0415\u041D", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--brand)'
    }
  }, "\u0421\u0415\u0419"))), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4
    }
  }, NAV.map(n => {
    const Ic = n.icon;
    const on = n.id === active;
    return /*#__PURE__*/React.createElement("button", {
      key: n.id,
      onClick: () => onNavigate && onNavigate(n.id),
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        padding: '11px 12px',
        cursor: 'pointer',
        fontFamily: 'var(--font-display)',
        fontWeight: 700,
        fontSize: 15,
        textAlign: 'left',
        color: on ? 'var(--text-on-brand)' : 'var(--brown-700)',
        background: on ? 'var(--ginger-500)' : 'transparent',
        border: on ? '2.5px solid var(--ink)' : '2.5px solid transparent',
        borderRadius: 'var(--radius-md)',
        boxShadow: on ? 'var(--pop-sm)' : 'none'
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      size: 20
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1
      }
    }, n.label), n.badge && /*#__PURE__*/React.createElement(__ds_scope.Badge, {
      tone: "live",
      dot: true
    }, n.badge));
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      display: 'flex',
      flexDirection: 'column',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("button", {
    style: navGhost
  }, /*#__PURE__*/React.createElement(__ds_scope.IconSettings, {
    size: 20
  }), /*#__PURE__*/React.createElement("span", null, "\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '10px',
      marginTop: 6,
      background: 'var(--cream-100)',
      border: '2px solid var(--sand-300)',
      borderRadius: 'var(--radius-lg)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Avatar, {
    name: "\u0418\u0432\u0430\u043D \u041A\u043E\u0442\u043E\u0432",
    size: "sm",
    online: true
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      lineHeight: 1.1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 14,
      color: 'var(--text-strong)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, "\u0418\u0432\u0430\u043D \u041A\u043E\u0442\u043E\u0432"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-muted)',
      fontWeight: 600
    }
  }, "\u0423\u0447\u0435\u043D\u0438\u043A \xB7 7 \u0443\u0440.")))));
}
const navGhost = {
  display: 'flex',
  alignItems: 'center',
  gap: 12,
  padding: '11px 12px',
  cursor: 'pointer',
  fontFamily: 'var(--font-display)',
  fontWeight: 700,
  fontSize: 15,
  textAlign: 'left',
  color: 'var(--brown-700)',
  background: 'transparent',
  border: '2.5px solid transparent',
  borderRadius: 'var(--radius-md)'
};
Object.assign(__ds_scope, { Sidebar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/Sidebar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/TopBar.jsx
try { (() => {
function TopBar({
  title = 'Главная'
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      height: 70,
      flex: 'none',
      display: 'flex',
      alignItems: 'center',
      gap: 18,
      padding: '0 28px',
      background: 'rgba(255,251,242,0.86)',
      backdropFilter: 'blur(8px)',
      borderBottom: '2.5px solid var(--ink)',
      position: 'sticky',
      top: 0,
      zIndex: 10
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 24,
      margin: 0
    }
  }, title), /*#__PURE__*/React.createElement("label", {
    style: {
      marginLeft: 18,
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      flex: 1,
      maxWidth: 420,
      background: 'var(--bg-surface)',
      border: '2.5px solid var(--sand-400)',
      borderRadius: 'var(--radius-pill)',
      padding: '9px 16px',
      color: 'var(--text-muted)'
    },
    className: "sx-search"
  }, /*#__PURE__*/React.createElement(__ds_scope.IconSearch, {
    size: 18
  }), /*#__PURE__*/React.createElement("input", {
    placeholder: "\u0418\u0441\u043A\u0430\u0442\u044C \u0433\u0430\u0439\u0434\u044B, \u0441\u0442\u0440\u0438\u043C\u044B, \u043B\u044E\u0434\u0435\u0439\u2026",
    style: {
      border: 'none',
      outline: 'none',
      background: 'transparent',
      flex: 1,
      fontFamily: 'var(--font-body)',
      fontSize: 14.5,
      fontWeight: 600,
      color: 'var(--text-strong)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      padding: '7px 14px',
      background: 'var(--gold-300)',
      border: '2.5px solid var(--ink)',
      borderRadius: 'var(--radius-pill)',
      boxShadow: 'var(--pop-sm)',
      color: 'var(--ink)'
    },
    className: "sx-xp"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--gold-700)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.IconStar, {
    size: 17,
    fill: true
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontWeight: 700,
      fontSize: 14
    }
  }, "2 480 XP")), /*#__PURE__*/React.createElement("button", {
    className: "sx-icon-btn",
    "aria-label": "\u0423\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F",
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.IconBell, {
    size: 20
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 7,
      right: 8,
      width: 9,
      height: 9,
      background: 'var(--danger-500)',
      border: '2px solid var(--bg-surface)',
      borderRadius: '50%'
    }
  })), /*#__PURE__*/React.createElement(__ds_scope.Avatar, {
    name: "\u0418\u0432\u0430\u043D \u041A\u043E\u0442\u043E\u0432",
    size: "md",
    online: true
  })));
}
Object.assign(__ds_scope, { TopBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/TopBar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/AppShell.jsx
try { (() => {
const TITLES = {
  home: 'Главная',
  feed: 'Лента',
  streams: 'Стримы',
  tournaments: 'Турниры',
  community: 'Додзё'
};
function AppShell() {
  const [active, setActive] = React.useState('home');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      minHeight: '100vh',
      background: 'var(--bg-page)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Sidebar, {
    active: active,
    onNavigate: setActive
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.TopBar, {
    title: TITLES[active] || 'Главная'
  }), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      overflow: 'auto'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Dashboard, null))));
}
Object.assign(__ds_scope, { AppShell });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/AppShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Hero.jsx
try { (() => {
function Hero() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: 0,
      background: 'radial-gradient(900px 520px at 78% 30%, var(--lavender-100), transparent 60%)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      zIndex: 1,
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '64px 24px 72px',
      display: 'grid',
      gridTemplateColumns: '1.05fr 0.95fr',
      gap: 32,
      alignItems: 'center'
    },
    className: "sx-hero-grid"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "sensei-eyebrow"
  }, "\u0420\u044B\u0436\u0438\u0439 \u043A\u043E\u0442 \xB7 \u0434\u0438\u0437\u0430\u0439\u043D"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 'clamp(40px, 6vw, 72px)',
      margin: '12px 0 18px',
      lineHeight: 0.98
    }
  }, "\u0423\u0447\u0438\u0441\u044C \u0443\xA0", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--brand)'
    }
  }, "\u0421\u0435\u043D\u0441\u0435\u044F"), ".", /*#__PURE__*/React.createElement("br", null), "\u041F\u043E\u0431\u0435\u0436\u0434\u0430\u0439 \u043A\u0440\u0430\u0441\u0438\u0432\u043E."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 19,
      color: 'var(--text-body)',
      maxWidth: '46ch',
      marginBottom: 28
    }
  }, "\u0420\u0430\u0437\u0431\u043E\u0440\u044B \u043C\u0430\u0442\u0447\u0435\u0439 Dota\xA02, \u043E\u0431\u0437\u043E\u0440\u044B \u0442\u0435\u0445\u043D\u0438\u043A\u0438 \u0438 \u0441\u043F\u043E\u043A\u043E\u0439\u043D\u044B\u0435 \u0433\u0430\u0439\u0434\u044B \u043E\u0442 \u0440\u044B\u0436\u0435\u0433\u043E \u043A\u043E\u0442\u0430-\u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A\u0430. \u0411\u0435\u0437 \u0432\u043E\u0434\u044B \u2014 \u0442\u043E\u043B\u044C\u043A\u043E \u0442\u043E, \u0447\u0442\u043E \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    size: "lg",
    iconLeft: /*#__PURE__*/React.createElement(__ds_scope.IconPlay, {
      size: 18
    })
  }, "\u0421\u043C\u043E\u0442\u0440\u0435\u0442\u044C \u0441\u0432\u0435\u0436\u0435\u0435"), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    size: "lg",
    variant: "cool",
    iconLeft: /*#__PURE__*/React.createElement(__ds_scope.IconSend, {
      size: 18
    })
  }, "Telegram-\u043A\u0430\u043D\u0430\u043B")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 28,
      marginTop: 34,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Stat, {
    icon: /*#__PURE__*/React.createElement(__ds_scope.IconUsers, {
      size: 18
    }),
    value: "128K",
    label: "\u043F\u043E\u0434\u043F\u0438\u0441\u0447\u0438\u043A\u043E\u0432"
  }), /*#__PURE__*/React.createElement(Stat, {
    icon: /*#__PURE__*/React.createElement(__ds_scope.IconEye, {
      size: 18
    }),
    value: "24M",
    label: "\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u043E\u0432"
  }), /*#__PURE__*/React.createElement(Stat, {
    icon: /*#__PURE__*/React.createElement(__ds_scope.IconPlay, {
      size: 18
    }),
    value: "340+",
    label: "\u0440\u043E\u043B\u0438\u043A\u043E\u0432"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'grid',
      placeItems: 'center',
      minHeight: 420
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "sensei-halo",
    style: {
      width: 'min(440px, 90%)',
      aspectRatio: '1',
      display: 'grid',
      placeItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/mascots/sensei-master.png",
    alt: "\u0421\u0435\u043D\u0441\u0435\u0439",
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'contain',
      filter: 'drop-shadow(0 18px 26px rgba(46,26,14,0.22))'
    }
  })), /*#__PURE__*/React.createElement(FloatChip, {
    style: {
      top: '8%',
      left: '2%'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: "live",
    dot: true
  }, "\u0412 \u042D\u0424\u0418\u0420\u0415")), /*#__PURE__*/React.createElement(FloatChip, {
    style: {
      bottom: '12%',
      right: '0%'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 14
    }
  }, "\uD83C\uDFC6 1-\u0435 \u043C\u0435\u0441\u0442\u043E")), /*#__PURE__*/React.createElement(FloatChip, {
    style: {
      top: '20%',
      right: '4%'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontWeight: 700,
      fontSize: 13,
      color: 'var(--ginger-700)'
    }
  }, "+2.4K \u0441\u0435\u0433\u043E\u0434\u043D\u044F")))));
}
function Stat({
  icon,
  value,
  label
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 38,
      height: 38,
      display: 'grid',
      placeItems: 'center',
      flex: 'none',
      background: 'var(--ginger-100)',
      color: 'var(--ginger-700)',
      border: '2px solid var(--ink)',
      borderRadius: 'var(--radius-md)'
    }
  }, icon), /*#__PURE__*/React.createElement("div", {
    style: {
      lineHeight: 1.05
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontWeight: 700,
      fontSize: 20,
      color: 'var(--text-strong)'
    }
  }, value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)',
      fontWeight: 600
    }
  }, label)));
}
function FloatChip({
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      background: 'var(--bg-surface)',
      border: '2.5px solid var(--ink)',
      borderRadius: 'var(--radius-pill)',
      boxShadow: 'var(--pop)',
      padding: '8px 14px',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Hero });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/SiteFooter.jsx
try { (() => {
const COLS = [{
  h: 'Канал',
  items: ['Видео', 'Стримы', 'Гайды', 'Плейлисты']
}, {
  h: 'Сообщество',
  items: ['Telegram', 'Discord', 'Чат', 'Правила']
}, {
  h: 'Ещё',
  items: ['Магазин', 'Реклама', 'Пресса', 'Контакты']
}];
function SiteFooter() {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--ink)',
      color: 'var(--cream-100)',
      borderTop: '3px solid var(--ink)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '56px 24px 28px',
      display: 'grid',
      gridTemplateColumns: '1.6fr 1fr 1fr 1fr',
      gap: 32
    },
    className: "sx-footer-grid"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/mascots/sensei-master.png",
    alt: "",
    style: {
      width: 46,
      height: 46,
      objectFit: 'contain'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 900,
      fontSize: 24
    }
  }, "\u0421\u0415\u041D", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--ginger-400)'
    }
  }, "\u0421\u0415\u0419"))), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--sand-300)',
      fontSize: 14.5,
      maxWidth: '34ch',
      lineHeight: 1.6
    }
  }, "\u0420\u044B\u0436\u0438\u0439 \u043A\u043E\u0442-\u043D\u0430\u0441\u0442\u0430\u0432\u043D\u0438\u043A \u043F\u0440\u043E Dota\xA02, \u0442\u0435\u0445\u043D\u0438\u043A\u0443 \u0438 \u0441\u043F\u043E\u043A\u043E\u0439\u043D\u044B\u0435 \u043F\u043E\u0431\u0435\u0434\u044B. \u0417\u0430\u0445\u043E\u0434\u0438 \u0432 \u0434\u043E\u0434\u0437\u0451."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      marginTop: 18
    }
  }, [/*#__PURE__*/React.createElement(__ds_scope.IconSend, {
    size: 18
  }), /*#__PURE__*/React.createElement(__ds_scope.IconVideo, {
    size: 18
  }), /*#__PURE__*/React.createElement(__ds_scope.IconHeart, {
    size: 18
  })].map((ic, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      width: 40,
      height: 40,
      display: 'grid',
      placeItems: 'center',
      background: 'rgba(255,251,242,0.08)',
      border: '2px solid rgba(255,251,242,0.18)',
      borderRadius: 'var(--radius-md)',
      color: 'var(--cream-50)'
    }
  }, ic)))), COLS.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.h
  }, /*#__PURE__*/React.createElement("h4", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 800,
      fontSize: 13,
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      color: 'var(--ginger-400)',
      margin: '0 0 14px'
    }
  }, c.h), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      margin: 0,
      padding: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 9
    }
  }, c.items.map(it => /*#__PURE__*/React.createElement("li", {
    key: it
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: 'var(--sand-300)',
      fontSize: 14.5,
      fontWeight: 600,
      textDecoration: 'none'
    }
  }, it))))))), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '18px 24px 40px',
      borderTop: '1px solid rgba(255,251,242,0.12)',
      display: 'flex',
      justifyContent: 'space-between',
      gap: 16,
      flexWrap: 'wrap',
      color: 'var(--sand-400)',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("span", null, "\xA9 2026 \u0421\u0435\u043D\u0441\u0435\u0439 \xB7 \u0420\u044B\u0436\u0438\u0439 \u043A\u043E\u0442 \u0434\u0438\u0437\u0430\u0439\u043D"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)'
    }
  }, "\u0421\u0434\u0435\u043B\u0430\u043D\u043E \u0441 \u0442\u0435\u043F\u043B\u043E\u043C \uD83D\uDC3E")));
}
Object.assign(__ds_scope, { SiteFooter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/SiteFooter.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/SiteHeader.jsx
try { (() => {
const NAV = ['Видео', 'Стримы', 'Гайды', 'Магазин', 'О канале'];
function SiteHeader({
  onSubscribe
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 20,
      background: 'rgba(255,251,242,0.86)',
      backdropFilter: 'blur(10px)',
      borderBottom: '2.5px solid var(--ink)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '12px 24px',
      display: 'flex',
      alignItems: 'center',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      textDecoration: 'none'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "sensei-halo",
    style: {
      width: 44,
      height: 44,
      display: 'grid',
      placeItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/mascots/sensei-master.png",
    alt: "\u0421\u0435\u043D\u0441\u0435\u0439",
    style: {
      width: 44,
      height: 44,
      objectFit: 'contain'
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 900,
      fontSize: 24,
      letterSpacing: '-0.02em',
      color: 'var(--text-strong)'
    }
  }, "\u0421\u0415\u041D", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--brand)'
    }
  }, "\u0421\u0415\u0419"))), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 4,
      marginLeft: 8
    },
    className: "sx-nav"
  }, NAV.map((n, i) => /*#__PURE__*/React.createElement("a", {
    key: n,
    href: "#",
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 15,
      color: i === 0 ? 'var(--ginger-700)' : 'var(--brown-700)',
      padding: '8px 12px',
      borderRadius: 'var(--radius-pill)',
      textDecoration: 'none'
    }
  }, n))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "sx-icon-btn",
    "aria-label": "\u041F\u043E\u0438\u0441\u043A"
  }, /*#__PURE__*/React.createElement(__ds_scope.IconSearch, {
    size: 20
  })), /*#__PURE__*/React.createElement("button", {
    className: "sx-icon-btn",
    "aria-label": "\u0423\u0432\u0435\u0434\u043E\u043C\u043B\u0435\u043D\u0438\u044F"
  }, /*#__PURE__*/React.createElement(__ds_scope.IconBell, {
    size: 20
  })), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    variant: "primary",
    size: "sm",
    iconLeft: /*#__PURE__*/React.createElement(__ds_scope.IconBell, {
      size: 15
    }),
    onClick: onSubscribe
  }, "\u041F\u043E\u0434\u043F\u0438\u0441\u0430\u0442\u044C\u0441\u044F"), /*#__PURE__*/React.createElement("button", {
    className: "sx-icon-btn sx-only-mobile",
    "aria-label": "\u041C\u0435\u043D\u044E"
  }, /*#__PURE__*/React.createElement(__ds_scope.IconMenu, {
    size: 22
  })))));
}
Object.assign(__ds_scope, { SiteHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/SiteHeader.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/SupportCTA.jsx
try { (() => {
function SupportCTA() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '0 24px 80px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      overflow: 'hidden',
      background: 'var(--lavender-200)',
      border: '3px solid var(--ink)',
      borderRadius: 'var(--radius-2xl)',
      boxShadow: 'var(--pop-lg)',
      display: 'grid',
      gridTemplateColumns: '1.4fr 0.9fr',
      gap: 24,
      alignItems: 'center',
      padding: '40px 44px'
    },
    className: "sx-cta"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    className: "sensei-eyebrow",
    style: {
      color: 'var(--grape-600)'
    }
  }, "\u0414\u043E\u0434\u0437\u0451 \u0421\u0435\u043D\u0441\u0435\u044F"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 38,
      margin: '10px 0 12px'
    }
  }, "\u041F\u043E\u0434\u0434\u0435\u0440\u0436\u0438 \u043A\u0430\u043D\u0430\u043B \u2014 \u0440\u0430\u0441\u0442\u0438 \u0432\u043C\u0435\u0441\u0442\u0435 \u0441 \u043D\u0430\u043C\u0438"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 17,
      color: 'var(--brown-700)',
      maxWidth: '48ch',
      marginBottom: 22
    }
  }, "\u0417\u0430\u043A\u0440\u044B\u0442\u044B\u0435 \u0441\u0442\u0440\u0438\u043C\u044B, \u0433\u0430\u0439\u0434\u044B \u0440\u0430\u043D\u044C\u0448\u0435 \u0432\u0441\u0435\u0445 \u0438 \u0442\u0451\u043F\u043B\u044B\u0439 \u0447\u0430\u0442. \u041F\u043E\u043C\u043E\u0433\u0438 \u0421\u0435\u043D\u0441\u0435\u044E \u0441\u043E\u0431\u0440\u0430\u0442\u044C \u043D\u0430 \u043D\u043E\u0432\u0443\u044E \u0441\u0442\u0443\u0434\u0438\u044E."), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 460,
      marginBottom: 24
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.ProgressBar, {
    label: "\u0426\u0435\u043B\u044C: \u043D\u043E\u0432\u0430\u044F \u0441\u0442\u0443\u0434\u0438\u044F",
    value: 128,
    max: 200,
    tone: "ginger"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Button, {
    size: "lg",
    variant: "accent",
    iconLeft: /*#__PURE__*/React.createElement(__ds_scope.IconHeart, {
      size: 18
    })
  }, "\u041F\u043E\u0434\u0434\u0435\u0440\u0436\u0430\u0442\u044C"), /*#__PURE__*/React.createElement(__ds_scope.Button, {
    size: "lg",
    variant: "secondary",
    iconLeft: /*#__PURE__*/React.createElement(__ds_scope.IconSend, {
      size: 18
    })
  }, "\u0412 Telegram"))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'grid',
      placeItems: 'center',
      minHeight: 240
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/mascots/sensei-trophy.png",
    alt: "",
    style: {
      width: 'min(280px, 100%)',
      objectFit: 'contain',
      filter: 'drop-shadow(0 16px 22px rgba(46,26,14,0.28))'
    }
  }))));
}
Object.assign(__ds_scope, { SupportCTA });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/SupportCTA.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/VideoGrid.jsx
try { (() => {
const VIDEOS = [{
  t: 'Как Сенсей собрал ПК за 80К',
  cat: 'Железо',
  tone: 'cyan',
  bg: 'var(--cyan-200)',
  dur: '14:22',
  views: '84K',
  when: '2 дня назад',
  live: false
}, {
  t: 'Разбор: почему ты сливаешь миды',
  cat: 'Dota 2',
  tone: 'ginger',
  bg: 'var(--ginger-200)',
  dur: '21:08',
  views: '212K',
  when: '5 дней назад',
  live: false
}, {
  t: 'Стрим: ранкеды до рассвета',
  cat: 'Стрим',
  tone: 'live',
  bg: 'var(--grape-500)',
  dur: 'LIVE',
  views: '3.1K',
  when: 'сейчас',
  live: true
}, {
  t: 'ТОП-5 наушников 2026 года',
  cat: 'Гаджеты',
  tone: 'grape',
  bg: 'var(--lavender-200)',
  dur: '11:40',
  views: '63K',
  when: 'неделю назад',
  live: false
}, {
  t: 'Гайд новичку: первые 100 часов',
  cat: 'Гайд',
  tone: 'ginger',
  bg: 'var(--gold-300)',
  dur: '18:55',
  views: '128K',
  when: '2 недели назад',
  live: false
}, {
  t: 'Реакция на патч 7.40',
  cat: 'Dota 2',
  tone: 'cyan',
  bg: 'var(--cyan-100)',
  dur: '09:30',
  views: '47K',
  when: '3 недели назад',
  live: false
}];
const TABS = [{
  id: 'all',
  label: 'Все'
}, {
  id: 'dota',
  label: 'Dota 2'
}, {
  id: 'tech',
  label: 'Техника'
}, {
  id: 'streams',
  label: 'Стримы'
}];
function Thumb({
  v
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: '100%',
      height: '100%',
      background: v.bg,
      display: 'grid',
      placeItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 900,
      fontSize: 13,
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: 'rgba(46,26,14,0.30)'
    }
  }, "\u0421\u0415\u041D\u0421\u0415\u0419"), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      width: 52,
      height: 52,
      display: 'grid',
      placeItems: 'center',
      background: 'var(--bg-surface)',
      color: 'var(--ginger-600)',
      border: '2.5px solid var(--ink)',
      borderRadius: '50%',
      boxShadow: 'var(--pop-sm)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.IconPlay, {
    size: 20
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 10,
      top: 10
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: v.live ? 'live' : 'neutral',
    dot: v.live
  }, v.live ? 'В ЭФИРЕ' : v.cat)), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: 10,
      bottom: 10,
      fontFamily: 'var(--font-mono)',
      fontWeight: 700,
      fontSize: 12,
      color: '#fff',
      background: 'rgba(46,26,14,0.82)',
      padding: '3px 8px',
      borderRadius: 'var(--radius-sm)'
    }
  }, v.dur));
}
function VideoGrid() {
  const [tab, setTab] = React.useState('all');
  return /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: 'var(--container-max)',
      margin: '0 auto',
      padding: '24px 24px 72px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 16,
      marginBottom: 24,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 34,
      margin: 0
    }
  }, "\u0421\u0432\u0435\u0436\u0438\u0435 \u0440\u043E\u043B\u0438\u043A\u0438"), /*#__PURE__*/React.createElement(__ds_scope.Tabs, {
    tabs: TABS,
    value: tab,
    onChange: setTab
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
      gap: 22
    }
  }, VIDEOS.map((v, i) => /*#__PURE__*/React.createElement(__ds_scope.Card, {
    key: i,
    variant: "sticker",
    interactive: true,
    media: /*#__PURE__*/React.createElement(Thumb, {
      v: v
    })
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 18,
      margin: '2px 0 0',
      lineHeight: 1.18
    }
  }, v.t), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      color: 'var(--text-muted)',
      fontSize: 13,
      fontWeight: 600,
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.IconEye, {
    size: 15
  }), v.views), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.IconClock, {
    size: 15
  }), v.when))))));
}
Object.assign(__ds_scope, { VideoGrid });
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/VideoGrid.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.ProgressBar = __ds_scope.ProgressBar;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.AppShell = __ds_scope.AppShell;

__ds_ns.Dashboard = __ds_scope.Dashboard;

__ds_ns.LoginScreen = __ds_scope.LoginScreen;

__ds_ns.Sidebar = __ds_scope.Sidebar;

__ds_ns.TopBar = __ds_scope.TopBar;

__ds_ns.Hero = __ds_scope.Hero;

__ds_ns.IconPlay = __ds_scope.IconPlay;

__ds_ns.IconBell = __ds_scope.IconBell;

__ds_ns.IconSend = __ds_scope.IconSend;

__ds_ns.IconSearch = __ds_scope.IconSearch;

__ds_ns.IconMenu = __ds_scope.IconMenu;

__ds_ns.IconHeart = __ds_scope.IconHeart;

__ds_ns.IconFire = __ds_scope.IconFire;

__ds_ns.IconHome = __ds_scope.IconHome;

__ds_ns.IconVideo = __ds_scope.IconVideo;

__ds_ns.IconTrophy = __ds_scope.IconTrophy;

__ds_ns.IconUsers = __ds_scope.IconUsers;

__ds_ns.IconChevron = __ds_scope.IconChevron;

__ds_ns.IconClock = __ds_scope.IconClock;

__ds_ns.IconEye = __ds_scope.IconEye;

__ds_ns.IconStar = __ds_scope.IconStar;

__ds_ns.IconGrid = __ds_scope.IconGrid;

__ds_ns.IconSettings = __ds_scope.IconSettings;

__ds_ns.SiteFooter = __ds_scope.SiteFooter;

__ds_ns.SiteHeader = __ds_scope.SiteHeader;

__ds_ns.SupportCTA = __ds_scope.SupportCTA;

__ds_ns.VideoGrid = __ds_scope.VideoGrid;

})();
